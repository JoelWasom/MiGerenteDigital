(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nSyntaxError: D:\\CreaSis\\MiGerenteDigital\\resources\\js\\src\\views\\Users\\PermisoUsuario.vue: Unexpected token, expected \")\" (311:35)\n\n\u001b[0m \u001b[90m 309 |\u001b[39m       params\u001b[33m.\u001b[39mappend(\u001b[32m\"idacceso\"\u001b[39m\u001b[33m,\u001b[39m item[\u001b[32m\"id\"\u001b[39m])\u001b[33m;\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 310 |\u001b[39m\u001b[0m\n\u001b[0m\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m 311 |\u001b[39m       \u001b[36mif\u001b[39m (item[\u001b[32m\"checked\"\u001b[39m] \u001b[33m===\u001b[39m \u001b[36mtrue\u001b[39m {\u001b[0m\n\u001b[0m \u001b[90m     |\u001b[39m                                    \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 312 |\u001b[39m         chek \u001b[33m=\u001b[39m \u001b[35m1\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 313 |\u001b[39m       } \u001b[36melse\u001b[39m {\u001b[0m\n\u001b[0m \u001b[90m 314 |\u001b[39m\u001b[0m\n    at instantiate (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:72:32)\n    at constructor (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:358:12)\n    at Object.raise (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:3335:19)\n    at Object.unexpected (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:3373:16)\n    at Object.expect (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:4002:28)\n    at Object.parseHeaderExpression (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:14827:10)\n    at Object.parseIfStatement (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:14930:22)\n    at Object.parseStatementContent (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:14584:21)\n    at Object.parseStatement (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:14533:17)\n    at Object.parseBlockOrModuleBlockBody (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:15176:25)\n    at Object.parseBlockBody (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:15167:10)\n    at Object.parseBlock (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:15151:10)\n    at Object.parseFunctionBody (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13841:24)\n    at Object.parseFunctionBodyAndFinish (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13825:10)\n    at Object.parseMethod (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13775:10)\n    at Object.parseObjectMethod (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13651:19)\n    at Object.parseObjPropValue (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13692:23)\n    at Object.parsePropertyDefinition (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13609:10)\n    at Object.parseObjectLike (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13499:21)\n    at Object.parseExprAtom (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12890:23)\n    at Object.parseExprAtom (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:8034:20)\n    at Object.parseExprSubscripts (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12540:23)\n    at Object.parseUpdate (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12519:21)\n    at Object.parseMaybeUnary (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12490:23)\n    at Object.parseMaybeUnaryOrPrivate (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12284:61)\n    at Object.parseExprOps (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12291:23)\n    at Object.parseMaybeConditional (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12261:23)\n    at Object.parseMaybeAssign (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12214:21)\n    at D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12172:39\n    at Object.allowInAnd (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:14242:12)\n    at Object.parseMaybeAssignAllowIn (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12172:17)\n    at Object.parseObjectProperty (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13659:101)\n    at Object.parseObjPropValue (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13692:100)\n    at Object.parsePropertyDefinition (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13609:10)\n    at Object.parseObjectLike (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:13499:21)\n    at Object.parseExprAtom (D:\\CreaSis\\MiGerenteDigital\\node_modules\\@babel\\parser\\lib\\index.js:12890:23)");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-overlay",
        {
          staticStyle: { height: "max-content" },
          attrs: {
            id: "overlay-background",
            variant: _vm.variant,
            opacity: _vm.opacity,
            blur: _vm.blur,
          },
        },
        [
          _c(
            "b-card",
            [
              _c("b-card-title", { staticStyle: { "text-align": "center" } }, [
                _vm._v("Asignación de Permisos"),
              ]),
              _vm._v(" "),
              _c(
                "b-card-body",
                [
                  _c(
                    "div",
                    [
                      _c(
                        "b-modal",
                        {
                          ref: "frm-perfil",
                          attrs: {
                            id: "frm-perfil",
                            "ok-title": "Guardar",
                            "ok-variant": "success",
                            "ok-disabled": _vm.ok,
                            "cancel-variant": "danger",
                            "cancel-title": "Cancelar",
                            centered: "",
                            title: "Asiganción de Permiso",
                          },
                          on: {
                            ok: _vm.guardarPerfil,
                            cancel: _vm.limpiarVariables,
                          },
                        },
                        [
                          _c(
                            "b-form",
                            [
                              _c(
                                "b-row",
                                [
                                  _c(
                                    "b-col",
                                    [
                                      _c("b-table", {
                                        ref: "selectableTable",
                                        attrs: {
                                          id: "tabla-lista-retrasos",
                                          items: _vm.itemMenu,
                                          fields: _vm.fieldsMenus,
                                          filter: _vm.filter,
                                          striped: "",
                                          hover: "",
                                          responsive: "sm",
                                          busy: _vm.isBusy,
                                          outlined: "",
                                          "sticky-header": _vm.stickyHeader,
                                        },
                                        on: { filtered: _vm.onFiltered },
                                        scopedSlots: _vm._u([
                                          {
                                            key: "cell(cheked)",
                                            fn: function (data) {
                                              return [
                                                _c("b-form-checkbox", {
                                                  class: {
                                                    "custom-control-success":
                                                      data.item.checked,
                                                    "custom-control-danger":
                                                      !data.item.checked,
                                                  },
                                                  attrs: {
                                                    checked: data.item.checked,
                                                  },
                                                  on: {
                                                    change: function ($event) {
                                                      return _vm.ModifiarPerfil(
                                                        data.item
                                                      )
                                                    },
                                                  },
                                                  model: {
                                                    value: data.item.checked,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        data.item,
                                                        "checked",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "data.item.checked",
                                                  },
                                                }),
                                              ]
                                            },
                                          },
                                          {
                                            key: "cell(Accion)",
                                            fn: function (row) {
                                              return [
                                                _c(
                                                  "b-button",
                                                  {
                                                    directives: [
                                                      {
                                                        name: "ripple",
                                                        rawName: "v-ripple.400",
                                                        value:
                                                          "rgba(255, 255, 255, 0.15)",
                                                        expression:
                                                          "'rgba(255, 255, 255, 0.15)'",
                                                        modifiers: {
                                                          400: true,
                                                        },
                                                      },
                                                    ],
                                                    staticClass:
                                                      "btn-icon rounded-circle",
                                                    attrs: {
                                                      variant: "danger",
                                                    },
                                                    on: {
                                                      click: function ($event) {
                                                        return _vm.ControlaEliminar(
                                                          row.item
                                                        )
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _c("feather-icon", {
                                                      attrs: {
                                                        icon: "TrashIcon",
                                                      },
                                                    }),
                                                  ],
                                                  1
                                                ),
                                              ]
                                            },
                                          },
                                          {
                                            key: "table-busy",
                                            fn: function () {
                                              return [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "text-center text-danger my-2",
                                                  },
                                                  [
                                                    _c("b-spinner", {
                                                      staticClass:
                                                        "align-middle",
                                                    }),
                                                    _vm._v(" "),
                                                    _c("strong", [
                                                      _vm._v("Cargando..."),
                                                    ]),
                                                  ],
                                                  1
                                                ),
                                              ]
                                            },
                                            proxy: true,
                                          },
                                        ]),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.shows
                            ? _c("b-spinner", {
                                staticClass: "mr-1",
                                attrs: {
                                  small: "",
                                  type: "grow",
                                  variant: _vm.estado,
                                },
                                model: {
                                  value: _vm.estado,
                                  callback: function ($$v) {
                                    _vm.estado = $$v
                                  },
                                  expression: "estado",
                                },
                              })
                            : _vm._e(),
                          _vm._v(
                            "\n            " +
                              _vm._s(_vm.Loading) +
                              "\n          "
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "b-row",
                    [
                      _c(
                        "b-col",
                        {
                          staticClass: "mb-1",
                          attrs: { sm: "4", md: "8", xl: "6" },
                        },
                        [
                          _c(
                            "b-button",
                            {
                              directives: [
                                {
                                  name: "ripple",
                                  rawName: "v-ripple.400",
                                  value: "rgba(113, 102, 240, 0.15)",
                                  expression: "'rgba(113, 102, 240, 0.15)'",
                                  modifiers: { 400: true },
                                },
                                {
                                  name: "b-modal",
                                  rawName: "v-b-modal.frm-perfil",
                                  modifiers: { "frm-perfil": true },
                                },
                              ],
                              attrs: { variant: "success" },
                            },
                            [
                              _vm._v(
                                "\n              Nuevo Registro\n            "
                              ),
                            ]
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "b-col",
                        {
                          staticClass: "mb-1",
                          attrs: { sm: "8", md: "4", xl: "6" },
                        },
                        [
                          _c(
                            "b-form-group",
                            {
                              staticClass: "mb-0",
                              attrs: {
                                "label-for": "filter-input",
                                "label-align-sm": "left",
                                "label-size": "sm",
                              },
                            },
                            [
                              _c(
                                "b-input-group",
                                { attrs: { size: "sm" } },
                                [
                                  _c("b-form-input", {
                                    attrs: {
                                      id: "filter-input",
                                      type: "search",
                                      placeholder: "Texto Para Buscar",
                                    },
                                    model: {
                                      value: _vm.filter,
                                      callback: function ($$v) {
                                        _vm.filter = $$v
                                      },
                                      expression: "filter",
                                    },
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            disabled: !_vm.filter,
                                            variant: "danger",
                                          },
                                          on: {
                                            click: function ($event) {
                                              _vm.filter = ""
                                            },
                                          },
                                        },
                                        [_vm._v("Clear")]
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "b-row",
                    [
                      _c(
                        "b-col",
                        [
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c(
                                    "b-alert",
                                    {
                                      directives: [
                                        {
                                          name: "height-fade",
                                          rawName: "v-height-fade.appear",
                                          modifiers: { appear: true },
                                        },
                                      ],
                                      staticClass: "mb-0",
                                      staticStyle: { height: "30px" },
                                      attrs: {
                                        show: _vm.dismissCountDown,
                                        dismissible: "",
                                        variant: "success",
                                      },
                                      on: {
                                        dismissed: function ($event) {
                                          _vm.dismissCountDown = 0
                                        },
                                        "dismiss-count-down":
                                          _vm.countDownChanged,
                                      },
                                    },
                                    [
                                      _c("div", { staticClass: "alert-body" }, [
                                        _c("span", [
                                          _vm._v(
                                            "Modificación Exitosa " +
                                              _vm._s(_vm.dismissCountDown) +
                                              "..."
                                          ),
                                        ]),
                                      ]),
                                    ]
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                {
                                  attrs: {
                                    xs: "12",
                                    sm: "12",
                                    md: "12",
                                    xl: "12",
                                    lg: "12",
                                  },
                                },
                                [
                                  _c("b-table", {
                                    style: { fontSize: _vm.fontSize },
                                    attrs: {
                                      id: "tabla-lista-roles",
                                      items: _vm.itemRol,
                                      fields: _vm.fieldsRol,
                                      filter: _vm.filter,
                                      hover: "",
                                      bordered: true,
                                      busy: _vm.isBusy,
                                      outlined: "",
                                      stacked: "sm",
                                      small: "",
                                    },
                                    on: { filtered: _vm.onFiltered },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "cell(accion)",
                                        fn: function (row) {
                                          return [
                                            _c(
                                              "b-button",
                                              {
                                                directives: [
                                                  {
                                                    name: "ripple",
                                                    rawName: "v-ripple.400",
                                                    value:
                                                      "rgba(234, 84, 85, 0.15)",
                                                    expression:
                                                      "'rgba(234, 84, 85, 0.15)'",
                                                    modifiers: { 400: true },
                                                  },
                                                ],
                                                staticClass:
                                                  "btn-icon rounded-circle",
                                                attrs: {
                                                  variant: "flat-danger",
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.ControlaEliminar(
                                                      row.item
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c("feather-icon", {
                                                  attrs: { icon: "LockIcon" },
                                                }),
                                              ],
                                              1
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "b-button",
                                              {
                                                directives: [
                                                  {
                                                    name: "ripple",
                                                    rawName: "v-ripple.400",
                                                    value:
                                                      "rgba(234, 84, 85, 0.15)",
                                                    expression:
                                                      "'rgba(234, 84, 85, 0.15)'",
                                                    modifiers: { 400: true },
                                                  },
                                                ],
                                                staticClass:
                                                  "btn-icon rounded-circle",
                                                attrs: { variant: "flat-info" },
                                                on: {
                                                  click: function ($event) {
                                                    _vm.validarClick2(
                                                      row.item,
                                                      "2"
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c("feather-icon", {
                                                  attrs: { icon: "EditIcon" },
                                                }),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                      {
                                        key: "table-busy",
                                        fn: function () {
                                          return [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "text-center text-danger my-2",
                                              },
                                              [
                                                _c("b-spinner", {
                                                  staticClass: "align-middle",
                                                }),
                                                _vm._v(" "),
                                                _c("strong", [
                                                  _vm._v("Cargando..."),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                        proxy: true,
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Users/PermisoUsuario.vue":
/*!*********************************************************!*\
  !*** ./resources/js/src/views/Users/PermisoUsuario.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PermisoUsuario.vue?vue&type=template&id=4728e10a& */ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&");
/* harmony import */ var _PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PermisoUsuario.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Users/PermisoUsuario.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PermisoUsuario.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PermisoUsuario.vue?vue&type=template&id=4728e10a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);