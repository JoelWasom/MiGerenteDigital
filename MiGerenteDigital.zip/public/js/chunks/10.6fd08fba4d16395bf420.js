(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _core_directives_animations__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @core/directives/animations */ "./resources/js/src/@core/directives/animations.js");










//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BAlert: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BAlert"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardText"],
    BFormCheckboxGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormCheckboxGroup"],
    BFormValidFeedback: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormValidFeedback"],
    BFormInvalidFeedback: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormInvalidFeedback"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BOverlay"],
    BFormDatepicker: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormDatepicker"],
    BInputGroupAppend: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BInputGroupAppend"],
    BInputGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BInputGroup"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BRow"],
    BModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BModal"],
    VBModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["VBModal"],
    BTable: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BTable"],
    BAvatar: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BAvatar"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardBody"],
    BCardHeader: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardHeader"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCard"],
    BDropdown: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BDropdown"],
    BDropdownItem: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BDropdownItem"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BButton"],
    BFormSelect: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormSelect"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormTextarea"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCol"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormGroup"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormInput"],
    BFormCheckbox: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormCheckbox"],
    BForm: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BForm"],
    BMedia: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BMedia"],
    BFormText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormText"],
    BFormDatalist: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormDatalist"],
    BBadge: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BBadge"],
    BSpinner: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BSpinner"]
  },
  props: {
    idperfil: String
  },
  directives: {
    "height-fade": _core_directives_animations__WEBPACK_IMPORTED_MODULE_12__["heightFade"],
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_11__["default"]
  },
  data: function data() {
    return {
      dismissSecs: 2,
      dismissCountDown: 0,
      stickyHeader: true,
      transProps: {
        // Transition name
        name: "flip-list"
      },
      fontSize: "",
      sele: [],
      perfil: "",
      promotores: "",
      pasivos: "",
      detractores: "",
      mesReporte: "",
      ok: false,
      shows: false,
      isBusy: false,
      totalRows: 1,
      loaded: false,
      filter: null,
      idGenera: 0,
      id: 0,
      fecha: 0,
      fechaRegistro: "",
      Loading: "",
      estado: "",
      items: [],
      itemMenu: [],
      itemRol: [],
      selelectedRol: [],
      selectedMenus: [],
      selectedPerfil: 1,
      aDataPerfil: [{
        value: null,
        text: "Seleccione un Valor"
      }],
      fieldsMenus: [{
        key: "Menu",
        label: "MENÚ"
      }, {
        key: "submenu",
        label: "SUB-MENÚ"
      }, {
        key: "cheked",
        label: "PERMITIR"
      }],
      fieldsRol: [{
        key: "id",
        label: "#"
      }, {
        key: "nombre",
        label: "NOMBRE"
      }, {
        key: "descripcion",
        label: "DESCRIPCIÓN"
      }, {
        key: "accion",
        label: "ACCIÓN"
      }],
      show: false,
      variant: "dark",
      opacity: 0.85,
      blur: "2px",
      selected: [],
      pidperfil: "",
      idmenu: "",
      menu: [],
      axiosP: false
    };
  },
  computed: {
    sortOptions: function sortOptions() {
      // Create an options list from our fields
      return this.fieldsMenus.filter(function (f) {
        return f.sortable;
      }).map(function (f) {
        return {
          text: f.label,
          value: f.key
        };
      });
    }
  },
  mounted: function mounted() {
    this.ListaRoles();
    var movil = window.innerWidth;

    if (movil <= 576) {
      // Dispositivo móvil pequeño
      this.fontSize = 'xx-small'; // Tamaño de fuente pequeño
    } // this.GenerarId();
    // alert(this.$store.state.app.msg)

  },
  methods: {
    countDownChanged: function countDownChanged(dismissCountDown) {
      this.dismissCountDown = dismissCountDown;
    },
    showAlert: function showAlert() {
      this.dismissCountDown = this.dismissSecs;
    },
    ModifiarPerfil: function ModifiarPerfil(item) {
      var me = this;
      me.show = true;
      var hoy = new Date();
      var fechaRegistro = MesActual(hoy, "yy-mm-dd HH:MM:SS.000000");
      me.fechaRegistro = fechaRegistro;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      me.pidperfil = me.selectedPerfil; // me.idmenu = item[0]["id"];

      var params = new URLSearchParams();
      var chek = 0;
      me.items = [];
      var urlm = "api/auth/ModificaAcceso";
      me.loaded = false; // me.isBusy = true;

      params.append("idacceso", item["id"]);

      if (item["checked"] === true) {
        chek = 1;
      } else {
        chek = 0;
      }

      params.append("checked", chek);
      axios.post(urlm, params).then(function (response) {
        var resp = response.data;

        if (response.status === 201) {
          me.show = false;
          me.showAlert(); // me.success("success");
          // me.UsuarioAlerta("success", response.data.mensaje)

          me.isBusy = false; // me.ListaPaginas();
        }
      })["catch"](function (e) {
        // alert("No se Modifico el acceso " + e);
        me.UsuarioAlerta("error" + e.response.data.error);
      });
      me.limpiarVariables();
    },
    ControlaEliminar: function ControlaEliminar(item) {
      var _this = this;

      this.boxTwo = "";
      this.$bvModal.msgBoxConfirm("El Registro  " + " : " + item["fecha"] + " Serán Eliminados", {
        title: "Advertencia",
        size: "sm",
        okVariant: "success",
        okTitle: "Continuar",
        cancelTitle: "Cancelar",
        cancelVariant: "danger",
        hideHeaderClose: true,
        centered: true
      }).then(function (value) {
        _this.boxTwo = value;

        if (value === true) {
          _this.eliminar(item);
        }
      });
    },
    eliminar: function eliminar(item) {
      this.isBusy = true;
      alert(item["idnps"]);
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams();
      var url = "api/auth/EliminarNps";
      params.append("idnps", parseInt(item["idnps"]));
      axios.post(url, params).then(function (response) {
        if (response.status === 200) {
          me.UsuarioAlerta("success", "Eliminación Exitosa");
          me.isBusy = false;
          me.ListaNps();
        }
      })["catch"](function (e) {
        alert("Error en la Eliminacion" + e);
      });
    },
    onFiltered: function onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
    },
    limpiarVariables: function limpiarVariables() {
      var me = this; // me.ListaPaginas();

      me.shows = false;
      me.loaded = false;
      me.Loading = "";
      me.filter = null;
      me.gestion = 0;
      me.mes = 0;
      me.iExiste = 0;
      me.estado = "";
    },
    //Listas
    ListaPaginas: function ListaPaginas() {
      var _this2 = this;

      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams(); // params.append('email', me.email);

      me.itemMenu = [];
      me.isBusy = true;
      var url = "api/auth/menu?idperfil=" + this.$store.state.app.idRolSelecionado;
      me.loaded = false;
      var lista = [];
      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var i = 0; i < resp.length; i++) {
          var estado = false;

          if (resp[i].checked === 1) {
            estado = true;
          } else {
            estado = false;
          }

          lista.push({
            id: resp[i].idacceso,
            Menu: resp[i].nombre_menu,
            submenu: resp[i].nombre_submenu,
            checked: estado
          });
        }

        me.itemMenu = lista;
        me.isBusy = false;
        me.loaded = true;
      })["catch"](function (e) {
        // alert("error al obtener los datos Lista Menu" + e);
        _this2.UsuarioAlerta("error", e.response.data.error);
      });
    },
    validarClick2: function validarClick2(item, click) {
      if (click === "2") {
        this.$store.dispatch('app/cambia_idRolSelecionado', item["id"]);
        this.ListaPaginas();
        this.$refs["frm-perfil"].show();
      }
    },
    ListaRoles: function ListaRoles() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams(); // params.append('email', me.email);

      me.itemRol = [];
      me.isBusy = true;
      var url = "api/auth/ListaRol";
      me.loaded = false;
      var lista = [];
      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var i = 0; i < resp.length; i++) {
          lista.push({
            id: resp[i].idrol,
            nombre: resp[i].nombre,
            descripcion: resp[i].descripcion
          });
        }

        me.itemRol = lista;
        me.isBusy = false;
        me.loaded = true;
      })["catch"](function (e) {
        alert("error al obtener los datos Lista Menu" + e);
      });
    },
    TraeMenuPerfil: function TraeMenuPerfil() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams(); // params.append('email', me.email);

      me.items = [];
      me.isBusy = true;
      var url = "api/auth/MenuPefil?idperfil=" + me.selectedPerfil;
      me.loaded = false;
      var lista = [];
      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var i = 0; i < resp.length; i++) {
          lista.push({
            id: resp[i].id_detalle_perfil,
            idperfil: resp[i].idperfil,
            nombre_perfil: resp[i].nombre_perfil,
            idmenu: resp[i].idmenu,
            name: resp[i].name,
            parent: resp[i].parent,
            estado: true
          });
        }

        me.items = lista;
        me.isBusy = false;
        me.loaded = true;
        me.menu = lista;
        prueba();
      })["catch"](function (e) {
        alert("error al obtener los datos Lista Menu Pefil" + e);
      });
    },
    dataGestion: function dataGestion() {
      var me = this;
      var url = "api/auth/ListaMenu";
      me.aDataPerfil = [{
        value: null,
        text: "Seleccione un Valor"
      }];

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");

      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var i = 0; i < resp.length; i++) {
          me.aDataPerfil.push({
            value: resp[i].idperfil,
            text: resp[i].nombre_perfil
          });
        }
      });
    },
    guardarPerfil: function guardarPerfil() {
      var me = this;
      me.show = true;
      var hoy = new Date();
      var fechaRegistro = MesActual(hoy, "yy-mm-dd HH:MM:SS.000000");
      me.fechaRegistro = fechaRegistro;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      me.pidperfil = me.selectedPerfil; // me.idmenu = item[0]["id"];

      var params = new URLSearchParams();
      me.items = [];
      var urlm = "api/auth/GuardarPerfil";
      me.loaded = false;
      me.isBusy = true;
      params.append("perfil", me.perfil); // params.append("idmenu", me.idmenu);
      // params.append("idusuario", this.$store.state.app.msg)

      axios.post(urlm, params).then(function (response) {
        var resp = response.data;

        if (response.status === 200) {
          me.show = false;
          me.success("success");
          me.isBusy = false;
          me.ListaPaginas();
          me.dataGestion();
        } else {
          me.success("danger");
        }
      })["catch"](function (e) {
        alert("No se guardo el Permiso " + e);
      });
      me.limpiarVariables();
    },
    Guardar: function Guardar(item) {
      var me = this;
      me.show = true;
      var hoy = new Date();
      var fechaRegistro = MesActual(hoy, "yy-mm-dd HH:MM:SS.000000");
      me.fechaRegistro = fechaRegistro;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      me.pidperfil = me.selectedPerfil;

      for (var i = 0; i < me.menu.length; i++) {
        me.idmenu = me.menu[i]["id"];
        var params = new URLSearchParams();
        me.items = [];
        var urlm = "api/auth/ModificaAcceso";
        me.loaded = false;
        me.isBusy = true;
        params.append("idacceso", item["id"]);
        axios.post(urlm, params).then(function (response) {
          var resp = response.data;

          if (response.status === 201 && me.menu.length) {
            me.show = false;
            me.TraeMenuPerfil();
            me.success("success");
            me.isBusy = false;
          } else {
            me.success("danger");
          }
        })["catch"](function (e) {
          alert("No se guardo el Permiso " + e);
        }); // me.limpiarVariables();
      }
    },
    UsuarioAlerta: function UsuarioAlerta(variant, msj) {
      var title, confirmButtonClass, showClass;

      if (variant === "success") {
        title = "Buen Trabajo";
        confirmButtonClass = "btn btn-success";
        showClass = "animate__animated animate__bounceIn";
      } else if (variant === "error") {
        title = "¡Error!";
        confirmButtonClass = "btn btn-danger";
        showClass = "btn btn-danger animate__animated animate__rubberBand";
      } else if (variant === "warning") {
        title = "Precaución";
        confirmButtonClass = "btn btn-warning";
        showClass = "animate__animated animate__wobble";
      } else {// Puedes agregar más casos según tus necesidades.
      }

      this.$swal({
        title: title,
        text: msj,
        icon: variant,
        customClass: {
          confirmButton: confirmButtonClass
        },
        showClass: {
          confirmButton: showClass
        },
        buttonsStyling: true
      });
    },
    success: function success(variant) {
      // window.swal = require('sweetalert2')
      if (variant === "success") {
        this.$swal({
          title: "HR Analytics",
          text: "Operación Exitosa",
          icon: variant,
          customClass: {
            confirmButton: "btn btn-success"
          },
          buttonsStyling: true
        });
      } else {
        this.$swal({
          title: "HR Analytics",
          text: "Operación sin Exito",
          icon: variant,
          customClass: {
            confirmButton: "btn btn-danger"
          },
          buttonsStyling: true
        });
      }
    },
    onContext: function onContext(ctx) {
      // The date formatted in the locale, or the `label-no - date - selected` string
      this.formatted = ctx.selectedFormatted; // The following will be an empty string until a valid date is entered

      this.mesReporte = ctx.selectedYMD;
    },
    selecionar: function selecionar(item) {
      var me = this;
      me.selected = item;
    },
    unselectThirdRow: function unselectThirdRow() {
      // Rows are indexed from 0, so the third row is index 2
      this.$refs.selectableTable.unselectRow(2);
    },
    selectThirdRow: function selectThirdRow() {
      // Rows are indexed from 0, so the third row is index 2
      this.$refs.selectableTable.selectRow(2);
    }
  }
});

function prueba() {
  this.$refs.selectableTable.selectRow(2);
}

function MesActual(fecha, formato) {
  // 2022-09-02 21:51:48.000000"
  var map = {
    dd: fecha.getDate(),
    mm: fecha.getMonth() + 1,
    yy: fecha.getFullYear().toString(),
    yyyy: fecha.getFullYear(),
    HH: fecha.getHours(),
    MM: fecha.getMinutes(),
    SS: fecha.getSeconds()
  }; // HH:MM:SS

  return formato.replace(/yy|mm|dd|HH|MM|SS/gi, function (matched) {
    return map[matched];
  });
}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-overlay",
        {
          staticStyle: { height: "max-content" },
          attrs: {
            id: "overlay-background",
            variant: _vm.variant,
            opacity: _vm.opacity,
            blur: _vm.blur,
          },
        },
        [
          _c(
            "b-card",
            [
              _c("b-card-title", { staticStyle: { "text-align": "center" } }, [
                _vm._v("Asignación de Permisos"),
              ]),
              _vm._v(" "),
              _c(
                "b-card-body",
                [
                  _c(
                    "div",
                    [
                      _c(
                        "b-modal",
                        {
                          ref: "frm-perfil",
                          attrs: {
                            id: "frm-perfil",
                            "ok-title": "Guardar",
                            "ok-variant": "success",
                            "ok-disabled": _vm.ok,
                            "cancel-variant": "danger",
                            "cancel-title": "Cancelar",
                            centered: "",
                            title: "Asiganción de Permiso",
                          },
                          on: {
                            ok: _vm.guardarPerfil,
                            cancel: _vm.limpiarVariables,
                          },
                        },
                        [
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c(
                                    "b-alert",
                                    {
                                      directives: [
                                        {
                                          name: "height-fade",
                                          rawName: "v-height-fade.appear",
                                          modifiers: { appear: true },
                                        },
                                      ],
                                      staticClass: "mb-0",
                                      staticStyle: { height: "30px" },
                                      attrs: {
                                        show: _vm.dismissCountDown,
                                        dismissible: "",
                                        variant: "success",
                                      },
                                      on: {
                                        dismissed: function ($event) {
                                          _vm.dismissCountDown = 0
                                        },
                                        "dismiss-count-down":
                                          _vm.countDownChanged,
                                      },
                                    },
                                    [
                                      _c("div", { staticClass: "alert-body" }, [
                                        _c("span", [
                                          _vm._v(
                                            "Modificación Exitosa " +
                                              _vm._s(_vm.dismissCountDown) +
                                              "..."
                                          ),
                                        ]),
                                      ]),
                                    ]
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-form",
                            [
                              _c(
                                "b-row",
                                [
                                  _c(
                                    "b-col",
                                    [
                                      _c("b-table", {
                                        ref: "selectableTable",
                                        attrs: {
                                          id: "tabla-lista-retrasos",
                                          items: _vm.itemMenu,
                                          fields: _vm.fieldsMenus,
                                          filter: _vm.filter,
                                          striped: "",
                                          hover: "",
                                          responsive: "sm",
                                          busy: _vm.isBusy,
                                          outlined: "",
                                          "sticky-header": _vm.stickyHeader,
                                        },
                                        on: { filtered: _vm.onFiltered },
                                        scopedSlots: _vm._u([
                                          {
                                            key: "cell(cheked)",
                                            fn: function (data) {
                                              return [
                                                _c("b-form-checkbox", {
                                                  attrs: {
                                                    checked: data.item.checked,
                                                  },
                                                  on: {
                                                    change: function ($event) {
                                                      return _vm.ModifiarPerfil(
                                                        data.item
                                                      )
                                                    },
                                                  },
                                                  model: {
                                                    value: data.item.checked,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        data.item,
                                                        "checked",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "data.item.checked",
                                                  },
                                                }),
                                              ]
                                            },
                                          },
                                          {
                                            key: "cell(Accion)",
                                            fn: function (row) {
                                              return [
                                                _c(
                                                  "b-button",
                                                  {
                                                    directives: [
                                                      {
                                                        name: "ripple",
                                                        rawName: "v-ripple.400",
                                                        value:
                                                          "rgba(255, 255, 255, 0.15)",
                                                        expression:
                                                          "'rgba(255, 255, 255, 0.15)'",
                                                        modifiers: {
                                                          400: true,
                                                        },
                                                      },
                                                    ],
                                                    staticClass:
                                                      "btn-icon rounded-circle",
                                                    attrs: {
                                                      variant: "danger",
                                                    },
                                                    on: {
                                                      click: function ($event) {
                                                        return _vm.ControlaEliminar(
                                                          row.item
                                                        )
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _c("feather-icon", {
                                                      attrs: {
                                                        icon: "TrashIcon",
                                                      },
                                                    }),
                                                  ],
                                                  1
                                                ),
                                              ]
                                            },
                                          },
                                          {
                                            key: "table-busy",
                                            fn: function () {
                                              return [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "text-center text-danger my-2",
                                                  },
                                                  [
                                                    _c("b-spinner", {
                                                      staticClass:
                                                        "align-middle",
                                                    }),
                                                    _vm._v(" "),
                                                    _c("strong", [
                                                      _vm._v("Cargando..."),
                                                    ]),
                                                  ],
                                                  1
                                                ),
                                              ]
                                            },
                                            proxy: true,
                                          },
                                        ]),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.shows
                            ? _c("b-spinner", {
                                staticClass: "mr-1",
                                attrs: {
                                  small: "",
                                  type: "grow",
                                  variant: _vm.estado,
                                },
                                model: {
                                  value: _vm.estado,
                                  callback: function ($$v) {
                                    _vm.estado = $$v
                                  },
                                  expression: "estado",
                                },
                              })
                            : _vm._e(),
                          _vm._v(
                            "\n            " +
                              _vm._s(_vm.Loading) +
                              "\n          "
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "b-row",
                    [
                      _c(
                        "b-col",
                        {
                          staticClass: "mb-1",
                          attrs: { sm: "4", md: "8", xl: "6" },
                        },
                        [
                          _c(
                            "b-button",
                            {
                              directives: [
                                {
                                  name: "ripple",
                                  rawName: "v-ripple.400",
                                  value: "rgba(113, 102, 240, 0.15)",
                                  expression: "'rgba(113, 102, 240, 0.15)'",
                                  modifiers: { 400: true },
                                },
                                {
                                  name: "b-modal",
                                  rawName: "v-b-modal.frm-perfil",
                                  modifiers: { "frm-perfil": true },
                                },
                              ],
                              attrs: { variant: "success" },
                            },
                            [
                              _vm._v(
                                "\n              Nuevo Registro\n            "
                              ),
                            ]
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "b-col",
                        {
                          staticClass: "mb-1",
                          attrs: { sm: "8", md: "4", xl: "6" },
                        },
                        [
                          _c(
                            "b-form-group",
                            {
                              staticClass: "mb-0",
                              attrs: {
                                "label-for": "filter-input",
                                "label-align-sm": "left",
                                "label-size": "sm",
                              },
                            },
                            [
                              _c(
                                "b-input-group",
                                { attrs: { size: "sm" } },
                                [
                                  _c("b-form-input", {
                                    attrs: {
                                      id: "filter-input",
                                      type: "search",
                                      placeholder: "Texto Para Buscar",
                                    },
                                    model: {
                                      value: _vm.filter,
                                      callback: function ($$v) {
                                        _vm.filter = $$v
                                      },
                                      expression: "filter",
                                    },
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "b-input-group-append",
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            disabled: !_vm.filter,
                                            variant: "danger",
                                          },
                                          on: {
                                            click: function ($event) {
                                              _vm.filter = ""
                                            },
                                          },
                                        },
                                        [_vm._v("Clear")]
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "b-row",
                    [
                      _c(
                        "b-col",
                        [
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                {
                                  attrs: {
                                    xs: "12",
                                    sm: "12",
                                    md: "12",
                                    xl: "12",
                                    lg: "12",
                                  },
                                },
                                [
                                  _c("b-table", {
                                    style: { fontSize: _vm.fontSize },
                                    attrs: {
                                      id: "tabla-lista-roles",
                                      items: _vm.itemRol,
                                      fields: _vm.fieldsRol,
                                      filter: _vm.filter,
                                      hover: "",
                                      bordered: true,
                                      busy: _vm.isBusy,
                                      outlined: "",
                                      stacked: "sm",
                                      small: "",
                                    },
                                    on: { filtered: _vm.onFiltered },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "cell(accion)",
                                        fn: function (row) {
                                          return [
                                            _c(
                                              "b-button",
                                              {
                                                directives: [
                                                  {
                                                    name: "ripple",
                                                    rawName: "v-ripple.400",
                                                    value:
                                                      "rgba(234, 84, 85, 0.15)",
                                                    expression:
                                                      "'rgba(234, 84, 85, 0.15)'",
                                                    modifiers: { 400: true },
                                                  },
                                                ],
                                                staticClass:
                                                  "btn-icon rounded-circle",
                                                attrs: {
                                                  variant: "flat-danger",
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.ControlaEliminar(
                                                      row.item
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c("feather-icon", {
                                                  attrs: { icon: "LockIcon" },
                                                }),
                                              ],
                                              1
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "b-button",
                                              {
                                                directives: [
                                                  {
                                                    name: "ripple",
                                                    rawName: "v-ripple.400",
                                                    value:
                                                      "rgba(234, 84, 85, 0.15)",
                                                    expression:
                                                      "'rgba(234, 84, 85, 0.15)'",
                                                    modifiers: { 400: true },
                                                  },
                                                ],
                                                staticClass:
                                                  "btn-icon rounded-circle",
                                                attrs: { variant: "flat-info" },
                                                on: {
                                                  click: function ($event) {
                                                    _vm.validarClick2(
                                                      row.item,
                                                      "2"
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c("feather-icon", {
                                                  attrs: { icon: "EditIcon" },
                                                }),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                      {
                                        key: "table-busy",
                                        fn: function () {
                                          return [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "text-center text-danger my-2",
                                              },
                                              [
                                                _c("b-spinner", {
                                                  staticClass: "align-middle",
                                                }),
                                                _vm._v(" "),
                                                _c("strong", [
                                                  _vm._v("Cargando..."),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                        proxy: true,
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/@core/directives/animations.js":
/*!*********************************************************!*\
  !*** ./resources/js/src/@core/directives/animations.js ***!
  \*********************************************************/
/*! exports provided: heightFade, temp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "heightFade", function() { return heightFade; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "temp", function() { return temp; });
var heightFade = {
  /* eslint-disable no-param-reassign */
  inserted: function inserted(el, binding) {
    var height = "".concat(el.offsetHeight, "px");

    if (binding.modifiers.appear) {
      el.style.overflow = 'hidden';
      el.style.maxHeight = '0px';
      el.style.opacity = 0; // Focus the element

      setTimeout(function () {
        el.style.maxHeight = height;
        el.style.opacity = 1;
        setTimeout(function () {
          el.style.overflow = 'unset';
        }, 300);
      }, 100);
    } else {
      el.style.maxHeight = height;
    }
  },
  unbind: function unbind(el) {
    if (el.style === undefined) return;
    el.style.overflow = 'hidden';
    el.style.maxHeight = '0px';
    el.style.opacity = 0;
  }
  /* eslint-enable no-param-reassign */

};
var temp = 2;

/***/ }),

/***/ "./resources/js/src/views/Users/PermisoUsuario.vue":
/*!*********************************************************!*\
  !*** ./resources/js/src/views/Users/PermisoUsuario.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PermisoUsuario.vue?vue&type=template&id=4728e10a& */ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&");
/* harmony import */ var _PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PermisoUsuario.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Users/PermisoUsuario.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PermisoUsuario.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PermisoUsuario.vue?vue&type=template&id=4728e10a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Users/PermisoUsuario.vue?vue&type=template&id=4728e10a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermisoUsuario_vue_vue_type_template_id_4728e10a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);