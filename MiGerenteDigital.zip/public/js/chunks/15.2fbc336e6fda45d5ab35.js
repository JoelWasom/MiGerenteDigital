(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[15],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BAvatar: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BAvatar"]
  },
  props: {
    variant: {
      type: String,
      "default": 'primary'
    },
    icon: {
      type: String,
      "default": null
    },
    title: {
      type: String,
      "default": null
    },
    text: {
      type: String,
      "default": null
    },
    hideClose: {
      type: Boolean,
      "default": false
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _frm_Venta_vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./frm_Venta.vue */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue");
/* harmony import */ var _Reportes_frmNotaVenta_vue__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./Reportes/frmNotaVenta.vue */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue");










//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 // import Ripple from "vue-ripple-directive";




 //   import Frm_Producto from "./frm_Producto/frm_Producto.vue";

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BButtonToolbar: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BButtonToolbar"],
    BButtonGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BButtonGroup"],
    VBTooltip: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["VBTooltip"],
    vSelect: vue_select__WEBPACK_IMPORTED_MODULE_12___default.a,
    BFormFile: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormFile"],
    BFormValidFeedback: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormValidFeedback"],
    BFormInvalidFeedback: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormInvalidFeedback"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BOverlay"],
    BFormDatepicker: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormDatepicker"],
    BInputGroupAppend: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BInputGroupAppend"],
    BInputGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BInputGroup"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BRow"],
    BModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BModal"],
    VBModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["VBModal"],
    BTable: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BTable"],
    BAvatar: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BAvatar"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardBody"],
    BCardHeader: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardHeader"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCard"],
    BDropdown: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BDropdown"],
    BDropdownItem: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BDropdownItem"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BButton"],
    BFormSelect: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormSelect"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormTextarea"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCol"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormGroup"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormInput"],
    BFormCheckbox: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormCheckbox"],
    BForm: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BForm"],
    BMedia: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BMedia"],
    BFormText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormText"],
    BFormDatalist: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormDatalist"],
    BBadge: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BBadge"],
    BSpinner: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BSpinner"],
    Frm_Venta: _frm_Venta_vue__WEBPACK_IMPORTED_MODULE_13__["default"],
    FrmNotaVenta: _Reportes_frmNotaVenta_vue__WEBPACK_IMPORTED_MODULE_14__["default"]
  },
  directive: {
    "b-tooltip": bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["VBTooltip"],
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_11__["default"]
  },
  data: function data() {
    return {
      txtCantidad: 0,
      TipoAccion: null,
      stickyHeader: true,
      transProps: {
        // Transition name
        name: "flip-list"
      },
      txtCodigoInterno: 0,
      totalVentas: 0,
      shows: true,
      isBusy: false,
      totalRows: 1,
      loaded: false,
      filter: "",
      filterOn: [],
      fecha: 0,
      fechaRegistro: "",
      Loading: "",
      estado: "",
      items: [],
      fields: [{
        key: "vntNumero",
        label: "Nª Venta",
        sortable: true
      }, {
        key: "cliNombre",
        label: "Cliente",
        sortable: true
      }, {
        key: "vntFechaCreacion",
        label: "Fecha de Venta",
        sortable: true
      }, {
        key: "totalVenta",
        label: "Total Venta",
        sortable: true
      }, {
        key: "FormaPago",
        label: "Forma de Pago",
        sortable: true
      }, {
        key: "Acción",
        sortable: false
      }],
      show: false,
      variant: "dark",
      opacity: 0.85,
      blur: "2px" // selected: [],

    };
  },
  computed: {
    sortOptions: function sortOptions() {
      // Create an options list from our fields
      return this.fields.filter(function (f) {
        return f.sortable;
      }).map(function (f) {
        return {
          text: f.label,
          value: f.key
        };
      });
    },
    totalVentaSum: function totalVentaSum() {
      return this.items.reduce(function (total, venta) {
        return total + parseFloat(venta.totalVenta);
      }, 0).toFixed(2);
    }
  },
  mounted: function mounted() {
    this.VerificarAperturaCaja();
    this.obtenerVentasRealizadas();
    this.clickAccion('', "apertura");
  },
  methods: {
    //Metodos Estandar
    clickAccion: function clickAccion(item, accion) {
      if (accion === "apertura") {
        this.$store.dispatch('app/cambiarTipoAccion', {
          tipo: accion,
          variant: 'success',
          icono: 'SaveIcon',
          texto: 'Apertura Caja',
          Bclass: ''
        });
      }

      if (accion === "guardar") {
        this.$store.dispatch('app/cambiarTipoAccion', {
          tipo: accion,
          variant: 'success',
          icono: 'SaveIcon',
          texto: 'Guardar',
          Bclass: ''
        });
      }

      if (accion === "editar") {
        this.$store.dispatch('app/cambiaId', item["artId"]);
        this.$store.dispatch('app/cambiarTipoAccion', {
          tipo: accion,
          variant: 'primary',
          icono: 'SaveIcon',
          texto: 'Modificar',
          Bclass: ''
        });
        this.$refs["frm-articulo"].show();
      }

      if (accion === "ver") {
        this.$store.dispatch('app/cambiaId', item["artId"]);
        this.$store.dispatch('app/cambiarTipoAccion', {
          tipo: accion,
          variant: 'success',
          icono: 'SaveIcon',
          texto: 'Guardar',
          Bclass: 'd-none'
        });
        this.$refs["frm-articulo"].show();
      }

      if (accion === "eliminar") {
        this.ControlaEliminar(item);
      }
    },
    UsuarioAlerta: function UsuarioAlerta(variant, msj) {
      var title, confirmButtonClass, showClass;

      if (variant === "success") {
        title = "Buen Trabajo";
        confirmButtonClass = "btn btn-success";
        showClass = "animate__animated animate__bounceIn";
      } else if (variant === "error") {
        title = "¡Error!";
        confirmButtonClass = "btn btn-danger";
        showClass = "btn btn-danger animate__animated animate__rubberBand";
      } else if (variant === "warning") {
        title = "Precaución";
        confirmButtonClass = "btn btn-warning";
        showClass = "animate__animated animate__wobble";
      } else {// Puedes agregar más casos según tus necesidades.
      }

      this.$swal({
        title: title,
        text: msj,
        icon: variant,
        customClass: {
          confirmButton: confirmButtonClass
        },
        showClass: {
          confirmButton: showClass
        },
        buttonsStyling: true
      });
    },
    ControlaEliminar: function ControlaEliminar(item) {
      var _this = this;

      this.boxTwo = "";
      this.$bvModal.msgBoxConfirm(" La Venta con N°:" + item["vntNumero"] + " Con ID " + item["vntId"] + " Serán Eliminados", {
        title: "Advertencia",
        size: "sm",
        okVariant: "success",
        okTitle: "Continuar",
        cancelTitle: "Cancelar",
        cancelVariant: "danger",
        hideHeaderClose: true,
        centered: true
      }).then(function (value) {
        _this.boxTwo = value;

        if (value === true) {
          _this.eliminar(item);
        }
      });
    },
    eliminar: function eliminar(item) {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams();
      params.append('vntId', item["vntId"]);
      params.append('userId', this.$store.state.app.UsuarioId);
      var url = "api/auth/InactiveVenta";
      me.isBusy = true;
      axios.post(url, params).then(function (response) {
        if (response.status == 201) {
          me.UsuarioAlerta("success", response.data.Mensaje);
          me.isBusy = false;
          me.obtenerVentasRealizadas();
        } else {
          me.UsuarioAlerta("error", response.data.error);
        }
      })["catch"](function (e) {
        me.UsuarioAlerta("error", e.response.data.error);
        console.log("danger", "No se Realizó la Operación: " + e.message);
      });
    },
    onFiltered: function onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
    },
    limpiarVariables: function limpiarVariables() {
      var me = this;
      me.shows = false;
      me.loaded = false;
      me.Loading = "";
      me.filter = null;
      me.filterOn = [];
      me.gestion = 0;
      me.mes = 0;
      me.iExiste = 0;
      me.estado = "";
    },
    makeToast: function makeToast(variant) {
      var me = this;

      if (variant === "success") {
        this.$bvToast.toast("Registro Exitoso ", {
          title: "HR Analytics",
          variant: variant,
          solid: true,
          appendToast: true
        });
      } else {
        this.$bvToast.toast("Error en el Registro ", {
          title: "HR Analytics",
          variant: variant,
          solid: true,
          appendToast: true
        });
      }
    },
    onContext: function onContext(ctx) {
      // The date formatted in the locale, or the `label-no - date - selected` string
      this.formatted = ctx.selectedFormatted; // The following will be an empty string until a valid date is entered

      this.mesReporte = ctx.selectedYMD;
    },
    //Metodos de logica de Negocios
    BuscarArticulo: function BuscarArticulo() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams();
      params.append('artCodigo', me.txtCodigoInterno);
      me.items = [];
      var url = "api/auth/TraeArticulo";
      me.loaded = false;
      var lista = [];
      axios.post(url, params).then(function (response) {
        var resp = response.data;
        lista.push({
          artId: resp[i].artId,
          codigo: resp[i].codigo,
          artNombre: resp[i].artNombre,
          catNombre: resp[i].catNombre,
          marNombre: resp[i].marNombre,
          uniNombre: resp[i].uniNombre,
          artCosto: resp[i].artCosto,
          artPrecioVenta: resp[i].artPrecioVenta,
          artCantidad: resp[i].artCantidad,
          artCantMin: resp[i].badgeColor
        });
        me.items = lista;
        me.loaded = true;
      })["catch"](function (e) {
        alert("error al obtener los datos Lista Articulo " + e);
      });
    },
    obtenerVentasRealizadas: function obtenerVentasRealizadas() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      me.items = [];
      me.isBusy = true;
      var url = "api/auth/obtenerVentasRealizadas";
      me.loaded = false;
      var lista = [];
      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var _i = 0; _i < resp.length; _i++) {
          lista.push({
            vntId: resp[_i].vntId,
            vntNumero: resp[_i].vntNumero,
            cliNombre: resp[_i].nombreCliente,
            vntFechaCreacion: resp[_i].vntFechaCreacion,
            totalVenta: resp[_i].totalVenta,
            FormaPago: resp[_i].FormaPago
          });
        }

        me.items = lista;
        me.isBusy = false;
        me.loaded = true;
      })["catch"](function (e) {
        alert("Error al obtener los datos de ventas realizadas: " + e);
      });
    },
    VerificarAperturaCaja: function VerificarAperturaCaja() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams();
      params.append('cajId', 1);
      me.items = [];
      var url = "api/auth/usuarioTieneCajaAbierta";
      me.loaded = false;
      var lista = [];
      axios.post(url, params).then(function (response) {
        var resp = response.data;

        if (response.status === 201) {
          me.UsuarioAlerta("warning", response.data.mensaje);
        } // me.items = lista;


        me.loaded = true;
      })["catch"](function (e) {
        me.UsuarioAlerta("error", e.response.data.error);
      });
    },
    CierreCaja: function CierreCaja() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams();
      params.append('cajId', 1);
      params.append('userId', this.$store.state.app.UsuarioId);
      me.items = [];
      var url = "api/auth/cerrarCaja";
      me.loaded = false;
      var lista = [];
      axios.post(url, params).then(function (response) {
        var resp = response.data;

        if (response.status === 201) {
          me.UsuarioAlerta("success", response.data.mensaje);
        } // me.items = lista;


        me.loaded = true;
      })["catch"](function (e) {
        me.UsuarioAlerta("error", e.response.data.error);
      });
    }
  }
});

function MesActual(fecha, formato) {
  // 2022-09-02 21:51:48.000000"
  var map = {
    dd: fecha.getDate(),
    mm: fecha.getMonth() + 1,
    yy: fecha.getFullYear().toString(),
    yyyy: fecha.getFullYear(),
    HH: fecha.getHours(),
    MM: fecha.getMinutes(),
    SS: fecha.getSeconds()
  }; // HH:MM:SS

  return formato.replace(/yy|mm|dd|HH|MM|SS/gi, function (matched) {
    return map[matched];
  });
}

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var html2pdf_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! html2pdf.js */ "./node_modules/html2pdf.js/dist/html2pdf.js");
/* harmony import */ var html2pdf_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(html2pdf_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.es.min.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_5__);



//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {};
  },
  methods: {
    generatePDF: function generatePDF() {
      // Crear un nuevo documento PDF
      var doc = new jspdf__WEBPACK_IMPORTED_MODULE_4__["default"]();
      var me = this; // Agregar el logo de la empresa (reemplaza 'ruta_al_logo' con la ruta de tu imagen)

      var xLogo = 10; // Posición x de la imagen

      var yLogo = 10; // Posición y de la imagen

      var anchoLogo = 50; // Ancho de la imagen

      var altoLogo = 50; // Alto de la imagen

      var image = new Image();
      var imgData = 'data:image/png;base64,' + me.$store.state.app.LogoEmpresa;
      doc.addImage(imgData, 'PNG', 5, 5, 25, 25);
      doc.setFont('helvetica', 'neue'); // doc.setFont('helvetica', 'bold');

      doc.setFontSize(18); // Configuración de la nota de venta

      var notaDeVenta = {
        numero: 'VE000001',
        fecha: '7 de noviembre de 2023',
        cliente: 'Ernesto Noco Ipavari',
        direccion: '123 Calle Principal',
        ciudad: 'Ciudad Ejemplo'
      }; // Datos de los productos

      var productos = [{
        nombre: 'Producto 1',
        cantidad: 2,
        precio: 20
      }, {
        nombre: 'Producto 2',
        cantidad: 3,
        precio: 15.50
      }, {
        nombre: 'Producto 3',
        cantidad: 1,
        precio: 30
      }, {
        nombre: 'Producto 4',
        cantidad: 5,
        precio: 10
      }]; // Crear una tabla para los productos

      var columns = ['Nombre', 'Cantidad', 'Precio', 'Total'];
      var rows = productos.map(function (producto) {
        return [producto.nombre, producto.cantidad, "".concat(producto.precio.toFixed(2)), "".concat((producto.cantidad * producto.precio).toFixed(2))];
      }); // Agregar el encabezado de la nota de venta

      doc.setFontSize(22);
      doc.setFont('helvetica', 'neue');
      doc.text('Nota de Venta', 145, 10, 'center');
      doc.setFontSize(14);
      doc.setFont('helvetica', 'neue');
      doc.text('N°:', 125, 20);
      doc.setTextColor(110, 107, 123);
      doc.text("".concat(notaDeVenta.numero), 135, 20);
      doc.setTextColor(0);
      doc.setFont('helvetica', 'neue');
      doc.text("Fecha: ".concat(notaDeVenta.fecha), 125, 28);
      doc.setFont('helvetica', 'neue');
      doc.setTextColor(0);
      doc.text("Cliente:", 5, 52);
      doc.setTextColor(100);
      doc.setFont('helvetica', 'neue');
      doc.text("".concat(notaDeVenta.cliente), 25, 52); // doc.text(`Dirección: ${notaDeVenta.direccion}`, 10, 44);
      // doc.text(`Ciudad: ${notaDeVenta.ciudad}`, 10, 52);
      // Agregar la tabla de productos

      doc.autoTable({
        startY: 60,
        head: [columns],
        body: rows
      }); // Calcular el total

      var total = productos.reduce(function (acc, producto) {
        return acc + producto.cantidad * producto.precio;
      }, 0);
      doc.setFont('helvetica', 'neue');
      doc.text("Total Bs.: ".concat(total.toFixed(2)), 145, doc.autoTable.previous.finalY + 10);
      doc.setFont('times', 'normal');
      doc.setFontSize(12); //// hasta aqui
      // Guardar el documento PDF
      // doc.save('nota_de_venta.pdf');
      // Guardar el documento PDF como un Data URI

      var dataUri = doc.output('datauristring'); // Abrir el PDF en una nueva ventana o pestaña

      var newWindow = window.open();
      newWindow.document.write('<iframe width="100%" height="100%" src="' + dataUri + '"></iframe');
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_CreaSis_MiGerenteDigital_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _core_components_toastification_ToastificationContent_vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @core/components/toastification/ToastificationContent.vue */ "./resources/js/src/@core/components/toastification/ToastificationContent.vue");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.es.min.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! jspdf-autotable */ "./node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.js");
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_15__);










//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    VBTooltip: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["VBTooltip"],
    ToastificationContent: _core_components_toastification_ToastificationContent_vue__WEBPACK_IMPORTED_MODULE_13__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BImg"],
    vSelect: vue_select__WEBPACK_IMPORTED_MODULE_12___default.a,
    BFormFile: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormFile"],
    BFormValidFeedback: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormValidFeedback"],
    BFormInvalidFeedback: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormInvalidFeedback"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BOverlay"],
    BFormDatepicker: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormDatepicker"],
    BInputGroupAppend: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BInputGroupAppend"],
    BInputGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BInputGroup"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BRow"],
    BModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BModal"],
    VBModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["VBModal"],
    BTable: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BTable"],
    BAvatar: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BAvatar"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardBody"],
    BCardHeader: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCardHeader"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCard"],
    BDropdown: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BDropdown"],
    BDropdownItem: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BDropdownItem"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BButton"],
    BFormSelect: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormSelect"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormTextarea"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BCol"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormGroup"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormInput"],
    BFormCheckbox: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormCheckbox"],
    BForm: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BForm"],
    BMedia: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BMedia"],
    BFormText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormText"],
    BFormDatalist: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormDatalist"],
    BBadge: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BBadge"],
    BSpinner: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BSpinner"],
    BFormSpinbutton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["BFormSpinbutton"]
  },
  data: function data() {
    return {
      tiposPago: [],
      SelectedtipoPago: null,
      // Tipo de pago seleccionado
      gntCliente: [],
      selectedCliente: null,
      tipoVenta: [{
        id: "0",
        title: "CONTADO"
      }, {
        id: "1",
        title: "CREDITO"
      }],
      selectedTipoVenta: null,
      totalPagar: 0,
      // Total a pagar
      montoRecibido: 0,
      cjtReferencia: 0,
      // Monto recibido
      cambio: 0,
      // Cambio a entregar
      vntNumero: "",
      isBusy: false,
      filter: "",
      stickyHeader: true,
      headVariant: "dark",
      booksProductos: [],
      selectedProductos: {
        id: "0",
        title: "",
        icon: 'ListIcon',
        precioV: 0,
        descuento: 0,
        cantidad: 0,
        subtotal: 0
      },
      itemsAgregado: [],
      fieldsAgregado: [{
        key: "id",
        label: "codigo",
        sortable: true,
        tdClass: "text-center text-bold"
      }, {
        key: "title",
        label: "PRODUCTO",
        sortable: true,
        tdClass: "text-left"
      }, {
        key: "precioV",
        label: "PRECIO",
        sortable: true,
        tdClass: "text-center text-bold"
      }, {
        key: "descuento",
        label: "DESCUENTO",
        sortable: true,
        tdClass: "text-center text-bold"
      }, {
        key: "cantidad",
        label: "CANTIDAD",
        sortable: false,
        tdClass: "text-center text-bold"
      }, {
        key: "subtotal",
        label: "SUBTOTAL",
        sortable: false,
        tdClass: "text-center text-bold"
      }, {
        key: "Acción",
        sortable: false,
        tdClass: "text-center"
      }]
    };
  },
  watch: {
    montoRecibido: function montoRecibido(nuevoMonto) {
      // Calcular el cambio
      this.cambio = nuevoMonto - this.totalPagar;
    }
  },
  directives: {
    "b-tooltip": bootstrap_vue__WEBPACK_IMPORTED_MODULE_10__["VBTooltip"],
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_11__["default"]
  },
  mounted: function mounted() {
    this.cbxArticulo();
    this.cbxFormaPago();
    this.cbxCliente();
  },
  computed: {
    totalPagarCalculado: function totalPagarCalculado() {
      var _this = this;

      return this.itemsAgregado.reduce(function (total, item) {
        if (item.descuento !== 0) {
          _this.totalPagar = total + item.descuento * item.cantidad;
        } else {
          _this.totalPagar = total + item.precioV * item.cantidad;
        }

        _this.montoRecibido = 0;
        _this.cambio = 0;
        return _this.totalPagar;
      }, 0);
    }
  },
  methods: {
    generatePDF: function generatePDF(Articulo) {
      try {
        // Crear un nuevo documento PDF
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_14__["default"]();

        var _me = this; // Agregar el logo de la empresa (reemplaza 'ruta_al_logo' con la ruta de tu imagen)


        var image = new Image();
        var imgData = 'data:image/png;base64,' + _me.$store.state.app.LogoEmpresa;
        doc.addImage(imgData, 'PNG', 15, 5, 25, 25);
        doc.setFont('helvetica', 'neue');
        doc.setFontSize(8); // doc.text(me.$store.state.app.NombreEmpresa, 40, 20);

        doc.text('DIRECCION : ' + _me.$store.state.app.DireccionEmpresa, 40, 20);
        doc.text('TELEFONO  : ' + _me.$store.state.app.TelefonoEmpresa, 40, 25);
        doc.text('Nit  : ' + _me.$store.state.app.NitEmpresa, 40, 30);
        var currentDate = new Date(); // Obtiene la fecha actual

        var options = {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        };
        var formattedDate = currentDate.toLocaleDateString('es-ES', options); // Formatea la fecha como "10/11/2023"
        // Configuración de la nota de venta

        var notaDeVenta = {
          numero: _me.cjtReferencia,
          fecha: formattedDate,
          cliente: _me.selectedCliente.title,
          direccion: '123 Calle Principal',
          ciudad: 'Ciudad Ejemplo'
        }; // Datos de los productos

        var columns = ['Articulo', 'Cantidad', 'PrecioUnitario', 'Descuento', 'SubTotal'];
        var rows = Articulo.map(function (producto) {
          var precioOriginal = parseFloat(producto.precioV);
          var precioUnitario = producto.descuento ? parseFloat(producto.descuento) : precioOriginal;
          var subtotal = precioUnitario * parseInt(producto.cantidad);
          return [producto.title || '', producto.cantidad || 0, precioOriginal.toFixed(2), // Mostrar el precio original en la columna 'Precio'
          producto.descuento || 0, subtotal.toFixed(2)];
        }); // Agregar el encabezado de la nota de venta

        doc.setFontSize(22);
        doc.setFont('helvetica', 'neue');
        doc.text('Nota de Venta', 135, 10);
        doc.setFontSize(14);
        doc.setFont('helvetica', 'neue');
        doc.text('N°:', 135, 20); // doc.setTextColor(110, 107, 123);

        doc.text("".concat(notaDeVenta.numero), 145, 20);
        doc.setTextColor(0);
        doc.setFont('helvetica', 'neue');
        doc.text("Fecha: ".concat(notaDeVenta.fecha), 135, 28);
        doc.setFont('helvetica', 'neue'); // doc.setTextColor(0);

        doc.text("Cliente:", 15, 52); // doc.setTextColor(100);

        doc.setFont('helvetica', 'neue');
        doc.text("".concat(notaDeVenta.cliente), 35, 52);
        var columnStyles = {
          0: {
            halign: 'text-left'
          },
          // Alineación centrada para la primera columna
          1: {
            halign: 'center'
          },
          // Alineación centrada para la segunda columna
          2: {
            halign: 'center'
          },
          // Alineación centrada para la tercera columna
          3: {
            halign: 'center'
          },
          // Alineación centrada para la cuarta columna
          4: {
            halign: 'center'
          } // Alineación centrada para la quinta columna

        }; // Agregar la tabla de productos

        doc.autoTable({
          startY: 60,
          head: [columns],
          body: rows,
          columnStyles: columnStyles
        }); // Calcular el total
        // const total = Articulo.reduce((acc, producto) => acc + parseFloat(producto.precioV) * parseInt(producto.cantidad), 0);

        var total = Articulo.reduce(function (acc, producto) {
          var precioUnitario = producto.descuento ? parseFloat(producto.descuento) : parseFloat(producto.precioV);
          var subtotal = precioUnitario * parseInt(producto.cantidad);
          return acc + subtotal;
        }, 0);
        doc.setFont('helvetica', 'neue');
        doc.text("Total Bs.:", 145, doc.autoTable.previous.finalY + 10);
        doc.text("".concat(total.toFixed(2)), 175, doc.autoTable.previous.finalY + 10);
        doc.setFont('times', 'normal');
        doc.setFontSize(12); // Guardar el documento PDF como un Data URI

        var dataUri = doc.output('datauristring'); // Abrir el PDF en una nueva ventana o pestaña

        var newWindow = window.open();
        newWindow.document.write('<iframe width="100%" height="100%" src="' + dataUri + '"></iframe');
      } catch (error) {
        me.UsuarioAlerta("error", "Error al generar el PDF: " + error.message);
      }
    },
    UsuarioAlerta: function UsuarioAlerta(variant, msj) {
      var title, confirmButtonClass, showClass;

      if (variant === "success") {
        title = "Buen Trabajo";
        confirmButtonClass = "btn btn-success";
        showClass = "animate__animated animate__bounceIn";
      } else if (variant === "error") {
        title = "¡Error!";
        confirmButtonClass = "btn btn-danger";
        showClass = "btn btn-danger animate__animated animate__rubberBand";
      } else if (variant === "warning") {
        title = "Precaución";
        confirmButtonClass = "btn btn-warning";
        showClass = "animate__animated animate__wobble";
      } else {// Puedes agregar más casos según tus necesidades.
      }

      this.$swal({
        title: title,
        text: msj,
        icon: variant,
        customClass: {
          confirmButton: confirmButtonClass
        },
        showClass: {
          confirmButton: showClass
        },
        buttonsStyling: true
      });
    },
    //eventos 
    cbxFormaPago: function cbxFormaPago() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams(); // params.append('email', me.email);
      // me.tiposPago = [];

      me.isBusy = true;
      var url = "api/auth/ListaFormaPago";
      me.loaded = false;
      var lista = [];
      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var i = 0; i < resp.length; i++) {
          lista.push({
            id: resp[i].fpId,
            title: resp[i].fpnombre
          });
        }

        me.tiposPago = lista;
        me.isBusy = false;
        me.loaded = true;
      })["catch"](function (e) {
        UsuarioAlerta("error", e.response.data.error);
      });
    },
    cbxArticulo: function cbxArticulo() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams(); // params.append('email', me.email);

      me.items = [];
      me.isBusy = true;
      var url = "api/auth/listArticulo";
      me.loaded = false;
      var lista = [];
      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var i = 0; i < resp.length; i++) {
          lista.push({
            id: resp[i].artId,
            title: resp[i].artNombre,
            icon: resp[i].artFoto,
            precioV: resp[i].artPrecioVenta,
            cantidad: resp[i].artCantidad
          });
        }

        me.booksProductos = lista;
        me.isBusy = false;
        me.loaded = true;
      })["catch"](function (e) {
        alert("error al obtener los datos Lista Articulo " + e);
      });
    },
    cbxCliente: function cbxCliente() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var params = new URLSearchParams(); // params.append('email', me.email);

      me.items = [];
      me.isBusy = true;
      var url = "api/auth/ListaCliente";
      me.loaded = false;
      var lista = [];
      axios.get(url).then(function (response) {
        var resp = response.data;

        for (var i = 0; i < resp.length; i++) {
          lista.push({
            id: resp[i].cliId,
            title: resp[i].cliNombre + " " + resp[i].cliApp + " " + resp[i].cliApm
          });
        }

        me.gntCliente = lista;
        me.isBusy = false;
        me.loaded = true;
      })["catch"](function (e) {
        alert("error al obtener los datos Lista Articulo " + e);
      });
    },
    cargarProducto: function cargarProducto() {
      var _this2 = this;

      if (this.selectedProductos) {
        // Verificar si el producto ya está en la lista itemsAgregado
        var productoExistente = this.itemsAgregado.find(function (item) {
          return item.id === _this2.selectedProductos.id;
        });

        if (!productoExistente) {
          // Si el producto no existe en la lista, lo agregamos
          this.itemsAgregado.push(Object(D_CreaSis_MiGerenteDigital_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(D_CreaSis_MiGerenteDigital_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, this.selectedProductos), {}, {
            descuento: 0,
            cantidad: 1,
            subtotal: this.selectedProductos.precioV
          }));
        } else {
          // Si el producto ya existe, puedes mostrar un mensaje de alerta o realizar otra acción
          this.UsuarioAlerta("error", 'El producto ya está en la lista');
        } // Resetea el valor de selectedProductos para deseleccionar la opción


        this.selectedProductos = null;
        this.$nextTick(function () {
          _this2.$refs.cantidadInput.focus();
        });
      }
    },
    //Metodos Con logica de Negocios
    vaciarControles: function vaciarControles() {
      var me = this;
      me.selectedCliente = null;
      me.selectedTipoVenta = null;
      me.SelectedtipoPago = null;
      me.itemsAgregado = [];
      me.montoRecibido = 0;
      me.cambio = 0;
      me.cbxArticulo();
    },
    GurdarMovimientoCaja: function GurdarMovimientoCaja() {
      var me = this;

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var formData = new FormData();
      formData.append("cajId", 1);
      formData.append("userId", this.$store.state.app.UsuarioId); // ID del usuario actual

      formData.append("cjtReferencia", me.cjtReferencia);
      formData.append("cjtModulo", "VENTAS");
      formData.append("cjtMonto", me.totalPagar);
      formData.append("cjtDescripcion", "Ingresos Por Venta");
      formData.append("ttxnId", 1);
      axios.post("api/auth/guardarMovimientoCaja", formData, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }).then(function (response) {
        if (response.status === 201) {
          console.log(response.data.mensaje);
        }
      })["catch"](function (e) {
        me.showOverlay = false;
        me.UsuarioAlerta("error", e.response.data.error);
      });
    },
    Guardar: function Guardar() {
      var me = this;
      me.showOverlay = true;
      var hoy = new Date();

      var axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js")["default"];

      var formData = new FormData();

      if (me.selectedCliente === null || me.selectedTipoVenta === null || me.SelectedtipoPago === null) {
        return me.UsuarioAlerta("error", "Faltan Datos Para Ingresar");
      }

      formData.append("cliId", me.selectedCliente.id); //  ID del cliente

      formData.append("userId", this.$store.state.app.UsuarioId); // ID del usuario actual

      formData.append("ttxId", 1); //ID del tipo de transacción 

      formData.append("vntCredito", me.selectedTipoVenta.id); // Esto puede ser 1 o 0 según corresponda (crédito o no)

      formData.append("fpId", me.SelectedtipoPago.id); //Forma de pago 

      formData.append("vntActivo", 1); // Esto puede ser 1 o 0 según corresponda (activo o no)
      // Construye un array de detalles de venta

      var detallesVenta = this.itemsAgregado.map(function (item) {
        return {
          artId: item.id,
          // ID del artículo
          vndCantidad: item.cantidad,
          // Cantidad vendida
          vndPrecioVenta: item.precioV,
          // Precio de venta
          vndDescuento: item.descuento,
          // Descuento (ajusta según necesites)
          vndActivo: 1 // Activo (ajusta según necesites)

        };
      });

      if (detallesVenta.length <= 0) {
        return me.UsuarioAlerta("error", "Debe Selecinar Ariculos");
      }

      formData.append("detallesVenta", JSON.stringify(detallesVenta));
      axios.post("api/auth/guardarVenta", formData, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }).then(function (response) {
        if (response.status === 201) {
          me.showOverlay = false;
          me.UsuarioAlerta("success", response.data.mensaje);
          me.cjtReferencia = response.data.cjtReferencia;
          me.GurdarMovimientoCaja();
          debugger;
          me.generatePDF(me.itemsAgregado);
          me.isBusy = false;
          me.vaciarControles();
        }
      })["catch"](function (e) {
        if (!e.response || !e.response.data || !e.response.data.error) {
          // No hay error específico
          me.showOverlay = false;
          me.UsuarioAlerta("error", e.response.data.error);
        } else {
          // Hay un mensaje de error específico
          me.showOverlay = false;
          me.UsuarioAlerta("error", "Error al Generar PDF" + e.message);
        } // me.showOverlay = false;
        // me.UsuarioAlerta("error", e.response ? e.response.data.error : "Error desconocido");

      });
    },
    actualizarCantidad: function actualizarCantidad(item, nuevaCantidad) {
      item.cantidad = nuevaCantidad;
    },
    precioDescuento: function precioDescuento(item, _precioDescuento) {
      item.descuento = _precioDescuento;
    },
    onFiltered: function onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
    },
    eliminarProducto: function eliminarProducto(index) {
      if (index >= 0 && index < this.itemsAgregado.length) {
        this.itemsAgregado.splice(index, 1);
        this.montoRecibido = 0;
        this.cambio = 0;
      }
    },
    ControlaEliminar: function ControlaEliminar(item, index) {
      var _this3 = this;

      this.boxTwo = "";
      this.$bvModal.msgBoxConfirm("El Registro  " + " : " + item["title"] + " Serán Eliminados", {
        title: "Advertencia",
        size: "sm",
        okVariant: "outline-success",
        okTitle: "Continuar",
        cancelTitle: "Cancelar",
        cancelVariant: "outline-danger",
        hideHeaderClose: true,
        centered: true
      }).then(function (value) {
        _this3.boxTwo = value;

        if (value === true) {
          _this3.eliminarProducto(index);
        }
      });
    },
    //Realiza la Operacion Correspondiente
    validaOperacion: function validaOperacion(accion) {
      if (accion === "guardar") {
        this.Guardar();
      }

      if (accion === "editar") {
        this.mofificar();
      }

      if (accion === "ver") {
        alert("ajecutara el ver");
      }
    },
    //Este evento elimina Articulo del Carrito
    clickAccion: function clickAccion(item, index, accion) {
      if (accion === "eliminar") {
        this.ControlaEliminar(item, index);
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".toastification-close-icon[data-v-7834b2fa],\n.toastification-title[data-v-7834b2fa] {\n  line-height: 26px;\n}\n.toastification-title[data-v-7834b2fa] {\n  color: inherit;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".v-select {\n  position: relative;\n  font-family: inherit;\n}\n.v-select,\n.v-select * {\n  box-sizing: border-box;\n}\n\n/* KeyFrames */\n@-webkit-keyframes vSelectSpinner-ltr {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(360deg);\n}\n}\n@-webkit-keyframes vSelectSpinner-rtl {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(-360deg);\n}\n}\n@keyframes vSelectSpinner-ltr {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(360deg);\n}\n}\n@keyframes vSelectSpinner-rtl {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(-360deg);\n}\n}\n/* Dropdown Default Transition */\n.vs__fade-enter-active,\n.vs__fade-leave-active {\n  pointer-events: none;\n  transition: opacity 0.15s cubic-bezier(1, 0.5, 0.8, 1);\n}\n.vs__fade-enter,\n.vs__fade-leave-to {\n  opacity: 0;\n}\n\n/** Component States */\n/*\n * Disabled\n *\n * When the component is disabled, all interaction\n * should be prevented. Here we modify the bg color,\n * and change the cursor displayed on the interactive\n * components.\n */\n[dir] .vs--disabled .vs__dropdown-toggle, [dir] .vs--disabled .vs__clear, [dir] .vs--disabled .vs__search, [dir] .vs--disabled .vs__selected, [dir] .vs--disabled .vs__open-indicator {\n  cursor: not-allowed;\n  background-color: #f8f8f8;\n}\n\n/*\n *  RTL - Right to Left Support\n *\n *  Because we're using a flexbox layout, the `dir=\"rtl\"`\n *  HTML attribute does most of the work for us by\n *  rearranging the child elements visually.\n */\n.v-select[dir=rtl] .vs__actions {\n  padding: 0 3px 0 6px;\n}\n.v-select[dir=rtl] .vs__clear {\n  margin-left: 6px;\n  margin-right: 0;\n}\n.v-select[dir=rtl] .vs__deselect {\n  margin-left: 0;\n  margin-right: 2px;\n}\n.v-select[dir=rtl] .vs__dropdown-menu {\n  text-align: right;\n}\n\n/**\n    Dropdown Toggle\n\n    The dropdown toggle is the primary wrapper of the component. It\n    has two direct descendants: .vs__selected-options, and .vs__actions.\n\n    .vs__selected-options holds the .vs__selected's as well as the\n    main search input.\n\n    .vs__actions holds the clear button and dropdown toggle.\n */\n.vs__dropdown-toggle {\n  appearance: none;\n  display: flex;\n  white-space: normal;\n}\n[dir] .vs__dropdown-toggle {\n  padding: 0 0 4px 0;\n  background: none;\n  border: 1px solid #d8d6de;\n  border-radius: 0.357rem;\n}\n.vs__selected-options {\n  display: flex;\n  flex-basis: 100%;\n  flex-grow: 1;\n  flex-wrap: wrap;\n  position: relative;\n}\n[dir] .vs__selected-options {\n  padding: 0 2px;\n}\n.vs__actions {\n  display: flex;\n  align-items: center;\n}\n[dir=ltr] .vs__actions {\n  padding: 4px 6px 0 3px;\n}\n[dir=rtl] .vs__actions {\n  padding: 4px 3px 0 6px;\n}\n\n/* Dropdown Toggle States */\n[dir] .vs--searchable .vs__dropdown-toggle {\n  cursor: text;\n}\n[dir] .vs--unsearchable .vs__dropdown-toggle {\n  cursor: pointer;\n}\n[dir] .vs--open .vs__dropdown-toggle {\n  border-bottom-color: transparent;\n}\n[dir=ltr] .vs--open .vs__dropdown-toggle {\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n[dir=rtl] .vs--open .vs__dropdown-toggle {\n  border-bottom-right-radius: 0;\n  border-bottom-left-radius: 0;\n}\n.vs__open-indicator {\n  fill: rgba(60, 60, 60, 0.5);\n  transition: transform 150ms cubic-bezier(1, -0.115, 0.975, 0.855);\n}\n[dir] .vs__open-indicator {\n  transform: scale(1);\n  transition-timing-function: cubic-bezier(1, -0.115, 0.975, 0.855);\n}\n[dir=ltr] .vs--open .vs__open-indicator {\n  transform: rotate(180deg) scale(1);\n}\n[dir=rtl] .vs--open .vs__open-indicator {\n  transform: rotate(-180deg) scale(1);\n}\n.vs--loading .vs__open-indicator {\n  opacity: 0;\n}\n\n/* Clear Button */\n.vs__clear {\n  fill: rgba(60, 60, 60, 0.5);\n}\n[dir] .vs__clear {\n  padding: 0;\n  border: 0;\n  background-color: transparent;\n  cursor: pointer;\n}\n[dir=ltr] .vs__clear {\n  margin-right: 8px;\n}\n[dir=rtl] .vs__clear {\n  margin-left: 8px;\n}\n\n/* Dropdown Menu */\n.vs__dropdown-menu {\n  display: block;\n  box-sizing: border-box;\n  position: absolute;\n  top: calc(100% - 1px);\n  z-index: 1000;\n  width: 100%;\n  max-height: 350px;\n  min-width: 160px;\n  overflow-y: auto;\n  list-style: none;\n}\n[dir] .vs__dropdown-menu {\n  padding: 5px 0;\n  margin: 0;\n  box-shadow: 0px 4px 25px 0px rgba(0, 0, 0, 0.1);\n  border: 1px solid #d8d6de;\n  border-top-style: none;\n  border-radius: 0 0 0.357rem 0.357rem;\n  background: #fff;\n}\n[dir=ltr] .vs__dropdown-menu {\n  left: 0;\n  text-align: left;\n}\n[dir=rtl] .vs__dropdown-menu {\n  right: 0;\n  text-align: right;\n}\n[dir] .vs__no-options {\n  text-align: center;\n}\n\n/* List Items */\n.vs__dropdown-option {\n  line-height: 1.42857143;\n  /* Normalize line height */\n  display: block;\n  color: #333;\n  /* Overrides most CSS frameworks */\n  white-space: nowrap;\n}\n[dir] .vs__dropdown-option {\n  padding: 3px 20px;\n  clear: both;\n}\n[dir] .vs__dropdown-option:hover {\n  cursor: pointer;\n}\n.vs__dropdown-option--highlight {\n  color: #7367f0 !important;\n}\n[dir] .vs__dropdown-option--highlight {\n  background: rgba(115, 103, 240, 0.12);\n}\n.vs__dropdown-option--disabled {\n  color: rgba(60, 60, 60, 0.5);\n}\n[dir] .vs__dropdown-option--disabled {\n  background: inherit;\n}\n[dir] .vs__dropdown-option--disabled:hover {\n  cursor: inherit;\n}\n\n/* Selected Tags */\n.vs__selected {\n  display: flex;\n  align-items: center;\n  color: #333;\n  line-height: 1.8;\n  z-index: 0;\n}\n[dir] .vs__selected {\n  background-color: #7367f0;\n  border: 0 solid rgba(60, 60, 60, 0.26);\n  border-radius: 0.357rem;\n  margin: 4px 2px 0px 2px;\n  padding: 0 0.25em;\n}\n.vs__deselect {\n  display: inline-flex;\n  appearance: none;\n  fill: rgba(60, 60, 60, 0.5);\n}\n[dir] .vs__deselect {\n  padding: 0;\n  border: 0;\n  cursor: pointer;\n  background: none;\n  text-shadow: 0 1px 0 #fff;\n}\n[dir=ltr] .vs__deselect {\n  margin-left: 4px;\n}\n[dir=rtl] .vs__deselect {\n  margin-right: 4px;\n}\n\n/* States */\n[dir] .vs--single .vs__selected {\n  background-color: transparent;\n  border-color: transparent;\n}\n.vs--single.vs--open .vs__selected {\n  position: absolute;\n  opacity: 0.4;\n}\n.vs--single.vs--searching .vs__selected {\n  display: none;\n}\n\n/* Search Input */\n/**\n * Super weird bug... If this declaration is grouped\n * below, the cancel button will still appear in chrome.\n * If it's up here on it's own, it'll hide it.\n */\n.vs__search::-webkit-search-cancel-button {\n  display: none;\n}\n.vs__search::-webkit-search-decoration,\n.vs__search::-webkit-search-results-button,\n.vs__search::-webkit-search-results-decoration,\n.vs__search::-ms-clear {\n  display: none;\n}\n.vs__search,\n.vs__search:focus {\n  appearance: none;\n  line-height: 1.8;\n  font-size: 1em;\n  outline: none;\n  width: 0;\n  max-width: 100%;\n  flex-grow: 1;\n  z-index: 1;\n}\n[dir] .vs__search, [dir] .vs__search:focus {\n  border: 1px solid transparent;\n  margin: 4px 0 0 0;\n  padding: 0 7px;\n  background: none;\n  box-shadow: none;\n}\n[dir=ltr] .vs__search, [dir=ltr] .vs__search:focus {\n  border-left: none;\n}\n[dir=rtl] .vs__search, [dir=rtl] .vs__search:focus {\n  border-right: none;\n}\n.vs__search::placeholder {\n  color: #6e6b7b;\n}\n\n/**\n    States\n */\n.vs--unsearchable .vs__search {\n  opacity: 1;\n}\n[dir] .vs--unsearchable:not(.vs--disabled) .vs__search:hover {\n  cursor: pointer;\n}\n.vs--single.vs--searching:not(.vs--open):not(.vs--loading) .vs__search {\n  opacity: 0.2;\n}\n\n/* Loading Spinner */\n.vs__spinner {\n  align-self: center;\n  opacity: 0;\n  font-size: 5px;\n  text-indent: -9999em;\n  overflow: hidden;\n  transition: opacity 0.1s;\n}\n[dir] .vs__spinner {\n  border-top: 0.9em solid rgba(100, 100, 100, 0.1);\n  border-bottom: 0.9em solid rgba(100, 100, 100, 0.1);\n  transform: translateZ(0);\n}\n[dir=ltr] .vs__spinner {\n  border-right: 0.9em solid rgba(100, 100, 100, 0.1);\n  border-left: 0.9em solid rgba(60, 60, 60, 0.45);\n  animation:  vSelectSpinner-ltr 1.1s infinite linear;\n}\n[dir=rtl] .vs__spinner {\n  border-left: 0.9em solid rgba(100, 100, 100, 0.1);\n  border-right: 0.9em solid rgba(60, 60, 60, 0.45);\n  animation:  vSelectSpinner-rtl 1.1s infinite linear;\n}\n.vs__spinner,\n.vs__spinner:after {\n  width: 5em;\n  height: 5em;\n}\n[dir] .vs__spinner, [dir] .vs__spinner:after {\n  border-radius: 50%;\n}\n\n/* Loading Spinner States */\n.vs--loading .vs__spinner {\n  opacity: 1;\n}\n.vs__open-indicator {\n  fill: none;\n}\n[dir] .vs__open-indicator {\n  margin-top: 0.15rem;\n}\n.vs__dropdown-toggle {\n  transition: all 0.25s ease-in-out;\n}\n[dir] .vs__dropdown-toggle {\n  padding: 0.59px 0 4px 0;\n}\n[dir=ltr] .vs--single .vs__dropdown-toggle {\n  padding-left: 6px;\n}\n[dir=rtl] .vs--single .vs__dropdown-toggle {\n  padding-right: 6px;\n}\n.vs__dropdown-option--disabled {\n  opacity: 0.5;\n}\n[dir] .vs__dropdown-option--disabled.vs__dropdown-option--selected {\n  background: #7367f0 !important;\n}\n.vs__dropdown-option {\n  color: #6e6b7b;\n}\n[dir] .vs__dropdown-option, [dir] .vs__no-options {\n  padding: 7px 20px;\n}\n.vs__dropdown-option--selected {\n  background-color: #7367f0;\n  color: #fff;\n  position: relative;\n}\n.vs__dropdown-option--selected::after {\n  content: \"\";\n  height: 1.1rem;\n  width: 1.1rem;\n  display: inline-block;\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n  right: 20px;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-check'%3E%3Cpolyline points='20 6 9 17 4 12'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 1.1rem;\n}\n[dir=rtl] .vs__dropdown-option--selected::after {\n  left: 20px;\n  right: unset;\n}\n.vs__dropdown-option--selected.vs__dropdown-option--highlight {\n  color: #fff !important;\n  background-color: #7367f0 !important;\n}\n.vs__clear svg {\n  color: #6e6b7b;\n}\n.vs__selected {\n  color: #fff;\n}\n.v-select.vs--single .vs__selected {\n  color: #6e6b7b;\n  transition: transform 0.2s ease;\n}\n[dir] .v-select.vs--single .vs__selected {\n  margin-top: 5px;\n}\n[dir=ltr] .v-select.vs--single .vs__selected input {\n  padding-left: 0;\n}\n[dir=rtl] .v-select.vs--single .vs__selected input {\n  padding-right: 0;\n}\n[dir=ltr] .vs--single.vs--open .vs__selected {\n  transform: translateX(5px);\n}\n[dir=rtl] .vs--single.vs--open .vs__selected {\n  transform: translateX(-5px);\n}\n.vs__selected .vs__deselect {\n  color: inherit;\n}\n.v-select:not(.vs--single) .vs__selected {\n  font-size: 0.9rem;\n}\n[dir] .v-select:not(.vs--single) .vs__selected {\n  border-radius: 3px;\n  padding: 0 0.6em;\n}\n[dir=ltr] .v-select:not(.vs--single) .vs__selected {\n  margin: 5px 2px 2px 5px;\n}\n[dir=rtl] .v-select:not(.vs--single) .vs__selected {\n  margin: 5px 5px 2px 2px;\n}\n.v-select:not(.vs--single) .vs__deselect svg {\n  vertical-align: text-top;\n}\n[dir] .v-select:not(.vs--single) .vs__deselect svg {\n  transform: scale(0.8);\n}\n.vs__dropdown-menu {\n  top: calc(100% + 1rem);\n}\n[dir] .vs__dropdown-menu {\n  border: none;\n  border-radius: 6px;\n  padding: 0;\n}\n[dir] .vs--open .vs__dropdown-toggle {\n  border-color: #7367f0;\n  border-bottom-color: #7367f0;\n  box-shadow: 0 3px 10px 0 rgba(34, 41, 47, 0.1);\n}\n[dir=ltr] .vs--open .vs__dropdown-toggle {\n  border-bottom-left-radius: 0.357rem;\n  border-bottom-right-radius: 0.357rem;\n}\n[dir=rtl] .vs--open .vs__dropdown-toggle {\n  border-bottom-right-radius: 0.357rem;\n  border-bottom-left-radius: 0.357rem;\n}\n.select-size-lg .vs__selected {\n  font-size: 1rem !important;\n}\n[dir] .select-size-lg.vs--single.vs--open .vs__selected {\n  margin-top: 6px;\n}\n.select-size-lg .vs__dropdown-toggle,\n.select-size-lg .vs__selected {\n  font-size: 1.25rem;\n}\n[dir] .select-size-lg .vs__dropdown-toggle {\n  padding: 5px;\n}\n[dir] .select-size-lg .vs__dropdown-toggle input {\n  margin-top: 0;\n}\n.select-size-lg .vs__deselect svg {\n  vertical-align: middle !important;\n}\n[dir] .select-size-lg .vs__deselect svg {\n  transform: scale(1) !important;\n}\n[dir] .select-size-sm .vs__dropdown-toggle {\n  padding-bottom: 0;\n  padding: 1px;\n}\n[dir] .select-size-sm.vs--single .vs__dropdown-toggle {\n  padding: 2px;\n}\n.select-size-sm .vs__dropdown-toggle,\n.select-size-sm .vs__selected {\n  font-size: 0.9rem;\n}\n[dir] .select-size-sm .vs__actions {\n  padding-top: 2px;\n  padding-bottom: 2px;\n}\n.select-size-sm .vs__deselect svg {\n  vertical-align: middle !important;\n}\n[dir] .select-size-sm .vs__search {\n  margin-top: 0;\n}\n.select-size-sm.v-select .vs__selected {\n  font-size: 0.75rem;\n}\n[dir] .select-size-sm.v-select .vs__selected {\n  padding: 0 0.3rem;\n}\n[dir] .select-size-sm.v-select:not(.vs--single) .vs__selected {\n  margin: 4px 5px;\n}\n[dir] .select-size-sm.v-select.vs--single .vs__selected {\n  margin-top: 1px;\n}\n[dir] .select-size-sm.vs--single.vs--open .vs__selected {\n  margin-top: 4px;\n}\n.dark-layout .vs__dropdown-toggle {\n  color: #b4b7bd;\n}\n[dir] .dark-layout .vs__dropdown-toggle {\n  background: #283046;\n  border-color: #404656;\n}\n.dark-layout .vs__selected-options input {\n  color: #b4b7bd;\n}\n.dark-layout .vs__selected-options input::placeholder {\n  color: #676d7d;\n}\n.dark-layout .vs__actions svg {\n  fill: #404656;\n}\n[dir] .dark-layout .vs__dropdown-menu {\n  background: #283046;\n}\n.dark-layout .vs__dropdown-menu li {\n  color: #b4b7bd;\n}\n.dark-layout .v-select:not(.vs--single) .vs__selected {\n  color: #7367f0;\n}\n[dir] .dark-layout .v-select:not(.vs--single) .vs__selected {\n  background-color: rgba(115, 103, 240, 0.12);\n}\n.dark-layout .v-select.vs--single .vs__selected {\n  color: #b4b7bd !important;\n}\n.dark-layout .vs--disabled .vs__dropdown-toggle,\n.dark-layout .vs--disabled .vs__clear,\n.dark-layout .vs--disabled .vs__search,\n.dark-layout .vs--disabled .vs__selected,\n.dark-layout .vs--disabled .vs__open-indicator {\n  opacity: 0.5;\n}\n[dir] .dark-layout .vs--disabled .vs__dropdown-toggle, [dir] .dark-layout .vs--disabled .vs__clear, [dir] .dark-layout .vs--disabled .vs__search, [dir] .dark-layout .vs--disabled .vs__selected, [dir] .dark-layout .vs--disabled .vs__open-indicator {\n  background-color: #283046;\n}\n.ecommerce-application .app-ecommerce-details .product-img {\n  width: 600px;\n}\n.ecommerce-application .app-ecommerce-details .ratings-list-item svg,\n.ecommerce-application .app-ecommerce-details .ratings-list-item i {\n  font-size: 1.286rem;\n  height: 1.286rem;\n  width: 1.286rem;\n}\n.ecommerce-application .app-ecommerce-details .filled-star {\n  fill: #ff9f43;\n  stroke: #ff9f43;\n  color: #ff9f43;\n}\n.ecommerce-application .app-ecommerce-details .unfilled-star {\n  stroke: #babfc7;\n  color: #babfc7;\n}\n.ecommerce-application .app-ecommerce-details .item-price {\n  color: #7367f0;\n}\n.ecommerce-application .app-ecommerce-details .item-company {\n  display: inline-flex;\n  font-weight: 400;\n  font-size: 0.875rem;\n}\n.ecommerce-application .app-ecommerce-details .item-company .company-name {\n  font-weight: 600;\n}\n[dir=ltr] .ecommerce-application .app-ecommerce-details .item-company .company-name {\n  margin-left: 0.25rem;\n}\n[dir=rtl] .ecommerce-application .app-ecommerce-details .item-company .company-name {\n  margin-right: 0.25rem;\n}\n[dir] .ecommerce-application .app-ecommerce-details .product-features {\n  margin-top: 1.5rem;\n  margin-bottom: 1.5rem;\n}\n.ecommerce-application .app-ecommerce-details .product-features li {\n  display: flex;\n  align-items: center;\n}\n[dir] .ecommerce-application .app-ecommerce-details .product-features li {\n  margin-bottom: 1rem;\n}\n.ecommerce-application .app-ecommerce-details .product-features li svg,\n.ecommerce-application .app-ecommerce-details .product-features li i {\n  height: 1.4rem;\n  width: 1.4rem;\n  font-size: 1.4rem;\n}\n[dir=ltr] .ecommerce-application .app-ecommerce-details .product-features li svg, [dir=ltr] .ecommerce-application .app-ecommerce-details .product-features li i {\n  margin-right: 0.75rem;\n}\n[dir=rtl] .ecommerce-application .app-ecommerce-details .product-features li svg, [dir=rtl] .ecommerce-application .app-ecommerce-details .product-features li i {\n  margin-left: 0.75rem;\n}\n.ecommerce-application .app-ecommerce-details .product-features li span {\n  font-weight: 600;\n}\n[dir] .ecommerce-application .app-ecommerce-details .product-color-options {\n  margin-top: 1.5rem;\n  margin-bottom: 1.2rem;\n}\n.ecommerce-application .app-ecommerce-details .btn-wishlist .text-danger {\n  color: #ea5455;\n  fill: #ea5455;\n}\n.ecommerce-application .app-ecommerce-details .btn-share .btn-icon ~ .dropdown-menu {\n  min-width: 3rem;\n}\n[dir] .ecommerce-application .app-ecommerce-details .item-features {\n  background-color: #f8f8f8;\n  padding-top: 5.357rem;\n  padding-bottom: 5.357rem;\n}\n.ecommerce-application .app-ecommerce-details .item-features i,\n.ecommerce-application .app-ecommerce-details .item-features svg {\n  font-size: 2.5rem;\n  height: 2.5rem;\n  width: 2.5rem;\n  color: #7367f0;\n}\n[dir] .ecommerce-application .swiper-responsive-breakpoints.swiper-container .swiper-slide {\n  text-align: center;\n  background-color: #f8f8f8;\n  padding: 1.5rem 3rem;\n  border-radius: 0.428rem;\n}\n.ecommerce-application .swiper-responsive-breakpoints.swiper-container .swiper-slide .img-container {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 250px;\n}\n.ecommerce-application .swiper-button-prev,\n.ecommerce-application .swiper-button-next,\n.ecommerce-application .swiper-container-rtl .swiper-button-prev,\n.ecommerce-application .swiper-container-rtl .swiper-button-next {\n  width: 35px;\n  font-size: 2rem;\n}\n[dir] .ecommerce-application .swiper-button-prev, [dir] .ecommerce-application .swiper-button-next, [dir] .ecommerce-application .swiper-container-rtl .swiper-button-prev, [dir] .ecommerce-application .swiper-container-rtl .swiper-button-next {\n  background-image: none;\n}\n.ecommerce-application .swiper-button-prev:focus,\n.ecommerce-application .swiper-button-next:focus,\n.ecommerce-application .swiper-container-rtl .swiper-button-prev:focus,\n.ecommerce-application .swiper-container-rtl .swiper-button-next:focus {\n  outline: none;\n}\n[dir=ltr] .ecommerce-application .swiper-button-prev {\n  left: 0;\n}\n[dir=rtl] .ecommerce-application .swiper-button-prev {\n  right: 0;\n}\n.ecommerce-application .swiper-button-prev:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n[dir=ltr] .ecommerce-application .swiper-button-next {\n  right: 0;\n}\n[dir=rtl] .ecommerce-application .swiper-button-next {\n  left: 0;\n}\n.ecommerce-application .swiper-button-next:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n.ecommerce-application .swiper-container-rtl .swiper-button-prev:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-container-rtl .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n.ecommerce-application .swiper-container-rtl .swiper-button-next:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-container-rtl .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n.ecommerce-application .product-color-options .color-option {\n  position: relative;\n}\n[dir] .ecommerce-application .product-color-options .color-option {\n  border: 1px solid transparent;\n  border-radius: 50%;\n  cursor: pointer;\n  padding: 3px;\n}\n.ecommerce-application .product-color-options .color-option .filloption {\n  height: 18px;\n  width: 18px;\n}\n[dir] .ecommerce-application .product-color-options .color-option .filloption {\n  border-radius: 50%;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-primary {\n  border-color: #7367f0;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-primary .filloption {\n  box-shadow: 0 2px 4px 0 rgba(115, 103, 240, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-success {\n  border-color: #28c76f;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-success .filloption {\n  box-shadow: 0 2px 4px 0 rgba(40, 199, 111, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-danger {\n  border-color: #ea5455;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-danger .filloption {\n  box-shadow: 0 2px 4px 0 rgba(234, 84, 85, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-warning {\n  border-color: #ff9f43;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-warning .filloption {\n  box-shadow: 0 2px 4px 0 rgba(255, 159, 67, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-info {\n  border-color: #00cfe8;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-info .filloption {\n  box-shadow: 0 2px 4px 0 rgba(0, 207, 232, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-primary .filloption {\n  box-shadow: 0 2px 4px 0 rgba(115, 103, 240, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-success .filloption {\n  box-shadow: 0 2px 4px 0 rgba(40, 199, 111, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-danger .filloption {\n  box-shadow: 0 2px 4px 0 rgba(234, 84, 85, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-warning .filloption {\n  box-shadow: 0 2px 4px 0 rgba(255, 159, 67, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-info .filloption {\n  box-shadow: 0 2px 4px 0 rgba(0, 207, 232, 0.4);\n}\n@media (max-width: 767.98px) {\n[dir] .ecommerce-application .swiper-responsive-breakpoints.swiper-container .swiper-slide {\n    padding: 1rem;\n}\n}\n@media (max-width: 767.98px) {\n.ecommerce-application .app-ecommerce-details .ratings-list-item svg,\n.ecommerce-application .app-ecommerce-details .ratings-list-item i {\n    font-size: 1rem;\n    height: 1rem;\n    width: 1rem;\n}\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_AT_RULE_IMPORT_0___ = __webpack_require__(/*! -!../../../../../../node_modules/css-loader/dist/cjs.js!sweetalert2/dist/sweetalert2.min.css */ "./node_modules/css-loader/dist/cjs.js!./node_modules/sweetalert2/dist/sweetalert2.min.css");
exports = ___CSS_LOADER_API_IMPORT___(false);
exports.i(___CSS_LOADER_AT_RULE_IMPORT_0___);
// Module
exports.push([module.i, "@charset \"UTF-8\";\n.v-select {\n  position: relative;\n  font-family: inherit;\n}\n.v-select,\n.v-select * {\n  box-sizing: border-box;\n}\n\n/* KeyFrames */\n@-webkit-keyframes vSelectSpinner-ltr {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(360deg);\n}\n}\n@-webkit-keyframes vSelectSpinner-rtl {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(-360deg);\n}\n}\n@keyframes vSelectSpinner-ltr {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(360deg);\n}\n}\n@keyframes vSelectSpinner-rtl {\n0% {\n    transform: rotate(0deg);\n}\n100% {\n    transform: rotate(-360deg);\n}\n}\n/* Dropdown Default Transition */\n.vs__fade-enter-active,\n.vs__fade-leave-active {\n  pointer-events: none;\n  transition: opacity 0.15s cubic-bezier(1, 0.5, 0.8, 1);\n}\n.vs__fade-enter,\n.vs__fade-leave-to {\n  opacity: 0;\n}\n\n/** Component States */\n/*\n * Disabled\n *\n * When the component is disabled, all interaction\n * should be prevented. Here we modify the bg color,\n * and change the cursor displayed on the interactive\n * components.\n */\n[dir] .vs--disabled .vs__dropdown-toggle, [dir] .vs--disabled .vs__clear, [dir] .vs--disabled .vs__search, [dir] .vs--disabled .vs__selected, [dir] .vs--disabled .vs__open-indicator {\n  cursor: not-allowed;\n  background-color: #f8f8f8;\n}\n\n/*\n *  RTL - Right to Left Support\n *\n *  Because we're using a flexbox layout, the `dir=\"rtl\"`\n *  HTML attribute does most of the work for us by\n *  rearranging the child elements visually.\n */\n.v-select[dir=rtl] .vs__actions {\n  padding: 0 3px 0 6px;\n}\n.v-select[dir=rtl] .vs__clear {\n  margin-left: 6px;\n  margin-right: 0;\n}\n.v-select[dir=rtl] .vs__deselect {\n  margin-left: 0;\n  margin-right: 2px;\n}\n.v-select[dir=rtl] .vs__dropdown-menu {\n  text-align: right;\n}\n\n/**\n    Dropdown Toggle\n\n    The dropdown toggle is the primary wrapper of the component. It\n    has two direct descendants: .vs__selected-options, and .vs__actions.\n\n    .vs__selected-options holds the .vs__selected's as well as the\n    main search input.\n\n    .vs__actions holds the clear button and dropdown toggle.\n */\n.vs__dropdown-toggle {\n  appearance: none;\n  display: flex;\n  white-space: normal;\n}\n[dir] .vs__dropdown-toggle {\n  padding: 0 0 4px 0;\n  background: none;\n  border: 1px solid #d8d6de;\n  border-radius: 0.357rem;\n}\n.vs__selected-options {\n  display: flex;\n  flex-basis: 100%;\n  flex-grow: 1;\n  flex-wrap: wrap;\n  position: relative;\n}\n[dir] .vs__selected-options {\n  padding: 0 2px;\n}\n.vs__actions {\n  display: flex;\n  align-items: center;\n}\n[dir=ltr] .vs__actions {\n  padding: 4px 6px 0 3px;\n}\n[dir=rtl] .vs__actions {\n  padding: 4px 3px 0 6px;\n}\n\n/* Dropdown Toggle States */\n[dir] .vs--searchable .vs__dropdown-toggle {\n  cursor: text;\n}\n[dir] .vs--unsearchable .vs__dropdown-toggle {\n  cursor: pointer;\n}\n[dir] .vs--open .vs__dropdown-toggle {\n  border-bottom-color: transparent;\n}\n[dir=ltr] .vs--open .vs__dropdown-toggle {\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n[dir=rtl] .vs--open .vs__dropdown-toggle {\n  border-bottom-right-radius: 0;\n  border-bottom-left-radius: 0;\n}\n.vs__open-indicator {\n  fill: rgba(60, 60, 60, 0.5);\n  transition: transform 150ms cubic-bezier(1, -0.115, 0.975, 0.855);\n}\n[dir] .vs__open-indicator {\n  transform: scale(1);\n  transition-timing-function: cubic-bezier(1, -0.115, 0.975, 0.855);\n}\n[dir=ltr] .vs--open .vs__open-indicator {\n  transform: rotate(180deg) scale(1);\n}\n[dir=rtl] .vs--open .vs__open-indicator {\n  transform: rotate(-180deg) scale(1);\n}\n.vs--loading .vs__open-indicator {\n  opacity: 0;\n}\n\n/* Clear Button */\n.vs__clear {\n  fill: rgba(60, 60, 60, 0.5);\n}\n[dir] .vs__clear {\n  padding: 0;\n  border: 0;\n  background-color: transparent;\n  cursor: pointer;\n}\n[dir=ltr] .vs__clear {\n  margin-right: 8px;\n}\n[dir=rtl] .vs__clear {\n  margin-left: 8px;\n}\n\n/* Dropdown Menu */\n.vs__dropdown-menu {\n  display: block;\n  box-sizing: border-box;\n  position: absolute;\n  top: calc(100% - 1px);\n  z-index: 1000;\n  width: 100%;\n  max-height: 350px;\n  min-width: 160px;\n  overflow-y: auto;\n  list-style: none;\n}\n[dir] .vs__dropdown-menu {\n  padding: 5px 0;\n  margin: 0;\n  box-shadow: 0px 4px 25px 0px rgba(0, 0, 0, 0.1);\n  border: 1px solid #d8d6de;\n  border-top-style: none;\n  border-radius: 0 0 0.357rem 0.357rem;\n  background: #fff;\n}\n[dir=ltr] .vs__dropdown-menu {\n  left: 0;\n  text-align: left;\n}\n[dir=rtl] .vs__dropdown-menu {\n  right: 0;\n  text-align: right;\n}\n[dir] .vs__no-options {\n  text-align: center;\n}\n\n/* List Items */\n.vs__dropdown-option {\n  line-height: 1.42857143;\n  /* Normalize line height */\n  display: block;\n  color: #333;\n  /* Overrides most CSS frameworks */\n  white-space: nowrap;\n}\n[dir] .vs__dropdown-option {\n  padding: 3px 20px;\n  clear: both;\n}\n[dir] .vs__dropdown-option:hover {\n  cursor: pointer;\n}\n.vs__dropdown-option--highlight {\n  color: #7367f0 !important;\n}\n[dir] .vs__dropdown-option--highlight {\n  background: rgba(115, 103, 240, 0.12);\n}\n.vs__dropdown-option--disabled {\n  color: rgba(60, 60, 60, 0.5);\n}\n[dir] .vs__dropdown-option--disabled {\n  background: inherit;\n}\n[dir] .vs__dropdown-option--disabled:hover {\n  cursor: inherit;\n}\n\n/* Selected Tags */\n.vs__selected {\n  display: flex;\n  align-items: center;\n  color: #333;\n  line-height: 1.8;\n  z-index: 0;\n}\n[dir] .vs__selected {\n  background-color: #7367f0;\n  border: 0 solid rgba(60, 60, 60, 0.26);\n  border-radius: 0.357rem;\n  margin: 4px 2px 0px 2px;\n  padding: 0 0.25em;\n}\n.vs__deselect {\n  display: inline-flex;\n  appearance: none;\n  fill: rgba(60, 60, 60, 0.5);\n}\n[dir] .vs__deselect {\n  padding: 0;\n  border: 0;\n  cursor: pointer;\n  background: none;\n  text-shadow: 0 1px 0 #fff;\n}\n[dir=ltr] .vs__deselect {\n  margin-left: 4px;\n}\n[dir=rtl] .vs__deselect {\n  margin-right: 4px;\n}\n\n/* States */\n[dir] .vs--single .vs__selected {\n  background-color: transparent;\n  border-color: transparent;\n}\n.vs--single.vs--open .vs__selected {\n  position: absolute;\n  opacity: 0.4;\n}\n.vs--single.vs--searching .vs__selected {\n  display: none;\n}\n\n/* Search Input */\n/**\n * Super weird bug... If this declaration is grouped\n * below, the cancel button will still appear in chrome.\n * If it's up here on it's own, it'll hide it.\n */\n.vs__search::-webkit-search-cancel-button {\n  display: none;\n}\n.vs__search::-webkit-search-decoration,\n.vs__search::-webkit-search-results-button,\n.vs__search::-webkit-search-results-decoration,\n.vs__search::-ms-clear {\n  display: none;\n}\n.vs__search,\n.vs__search:focus {\n  appearance: none;\n  line-height: 1.8;\n  font-size: 1em;\n  outline: none;\n  width: 0;\n  max-width: 100%;\n  flex-grow: 1;\n  z-index: 1;\n}\n[dir] .vs__search, [dir] .vs__search:focus {\n  border: 1px solid transparent;\n  margin: 4px 0 0 0;\n  padding: 0 7px;\n  background: none;\n  box-shadow: none;\n}\n[dir=ltr] .vs__search, [dir=ltr] .vs__search:focus {\n  border-left: none;\n}\n[dir=rtl] .vs__search, [dir=rtl] .vs__search:focus {\n  border-right: none;\n}\n.vs__search::placeholder {\n  color: #6e6b7b;\n}\n\n/**\n    States\n */\n.vs--unsearchable .vs__search {\n  opacity: 1;\n}\n[dir] .vs--unsearchable:not(.vs--disabled) .vs__search:hover {\n  cursor: pointer;\n}\n.vs--single.vs--searching:not(.vs--open):not(.vs--loading) .vs__search {\n  opacity: 0.2;\n}\n\n/* Loading Spinner */\n.vs__spinner {\n  align-self: center;\n  opacity: 0;\n  font-size: 5px;\n  text-indent: -9999em;\n  overflow: hidden;\n  transition: opacity 0.1s;\n}\n[dir] .vs__spinner {\n  border-top: 0.9em solid rgba(100, 100, 100, 0.1);\n  border-bottom: 0.9em solid rgba(100, 100, 100, 0.1);\n  transform: translateZ(0);\n}\n[dir=ltr] .vs__spinner {\n  border-right: 0.9em solid rgba(100, 100, 100, 0.1);\n  border-left: 0.9em solid rgba(60, 60, 60, 0.45);\n  animation:  vSelectSpinner-ltr 1.1s infinite linear;\n}\n[dir=rtl] .vs__spinner {\n  border-left: 0.9em solid rgba(100, 100, 100, 0.1);\n  border-right: 0.9em solid rgba(60, 60, 60, 0.45);\n  animation:  vSelectSpinner-rtl 1.1s infinite linear;\n}\n.vs__spinner,\n.vs__spinner:after {\n  width: 5em;\n  height: 5em;\n}\n[dir] .vs__spinner, [dir] .vs__spinner:after {\n  border-radius: 50%;\n}\n\n/* Loading Spinner States */\n.vs--loading .vs__spinner {\n  opacity: 1;\n}\n.vs__open-indicator {\n  fill: none;\n}\n[dir] .vs__open-indicator {\n  margin-top: 0.15rem;\n}\n.vs__dropdown-toggle {\n  transition: all 0.25s ease-in-out;\n}\n[dir] .vs__dropdown-toggle {\n  padding: 0.59px 0 4px 0;\n}\n[dir=ltr] .vs--single .vs__dropdown-toggle {\n  padding-left: 6px;\n}\n[dir=rtl] .vs--single .vs__dropdown-toggle {\n  padding-right: 6px;\n}\n.vs__dropdown-option--disabled {\n  opacity: 0.5;\n}\n[dir] .vs__dropdown-option--disabled.vs__dropdown-option--selected {\n  background: #7367f0 !important;\n}\n.vs__dropdown-option {\n  color: #6e6b7b;\n}\n[dir] .vs__dropdown-option, [dir] .vs__no-options {\n  padding: 7px 20px;\n}\n.vs__dropdown-option--selected {\n  background-color: #7367f0;\n  color: #fff;\n  position: relative;\n}\n.vs__dropdown-option--selected::after {\n  content: \"\";\n  height: 1.1rem;\n  width: 1.1rem;\n  display: inline-block;\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n  right: 20px;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-check'%3E%3Cpolyline points='20 6 9 17 4 12'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 1.1rem;\n}\n[dir=rtl] .vs__dropdown-option--selected::after {\n  left: 20px;\n  right: unset;\n}\n.vs__dropdown-option--selected.vs__dropdown-option--highlight {\n  color: #fff !important;\n  background-color: #7367f0 !important;\n}\n.vs__clear svg {\n  color: #6e6b7b;\n}\n.vs__selected {\n  color: #fff;\n}\n.v-select.vs--single .vs__selected {\n  color: #6e6b7b;\n  transition: transform 0.2s ease;\n}\n[dir] .v-select.vs--single .vs__selected {\n  margin-top: 5px;\n}\n[dir=ltr] .v-select.vs--single .vs__selected input {\n  padding-left: 0;\n}\n[dir=rtl] .v-select.vs--single .vs__selected input {\n  padding-right: 0;\n}\n[dir=ltr] .vs--single.vs--open .vs__selected {\n  transform: translateX(5px);\n}\n[dir=rtl] .vs--single.vs--open .vs__selected {\n  transform: translateX(-5px);\n}\n.vs__selected .vs__deselect {\n  color: inherit;\n}\n.v-select:not(.vs--single) .vs__selected {\n  font-size: 0.9rem;\n}\n[dir] .v-select:not(.vs--single) .vs__selected {\n  border-radius: 3px;\n  padding: 0 0.6em;\n}\n[dir=ltr] .v-select:not(.vs--single) .vs__selected {\n  margin: 5px 2px 2px 5px;\n}\n[dir=rtl] .v-select:not(.vs--single) .vs__selected {\n  margin: 5px 5px 2px 2px;\n}\n.v-select:not(.vs--single) .vs__deselect svg {\n  vertical-align: text-top;\n}\n[dir] .v-select:not(.vs--single) .vs__deselect svg {\n  transform: scale(0.8);\n}\n.vs__dropdown-menu {\n  top: calc(100% + 1rem);\n}\n[dir] .vs__dropdown-menu {\n  border: none;\n  border-radius: 6px;\n  padding: 0;\n}\n[dir] .vs--open .vs__dropdown-toggle {\n  border-color: #7367f0;\n  border-bottom-color: #7367f0;\n  box-shadow: 0 3px 10px 0 rgba(34, 41, 47, 0.1);\n}\n[dir=ltr] .vs--open .vs__dropdown-toggle {\n  border-bottom-left-radius: 0.357rem;\n  border-bottom-right-radius: 0.357rem;\n}\n[dir=rtl] .vs--open .vs__dropdown-toggle {\n  border-bottom-right-radius: 0.357rem;\n  border-bottom-left-radius: 0.357rem;\n}\n.select-size-lg .vs__selected {\n  font-size: 1rem !important;\n}\n[dir] .select-size-lg.vs--single.vs--open .vs__selected {\n  margin-top: 6px;\n}\n.select-size-lg .vs__dropdown-toggle,\n.select-size-lg .vs__selected {\n  font-size: 1.25rem;\n}\n[dir] .select-size-lg .vs__dropdown-toggle {\n  padding: 5px;\n}\n[dir] .select-size-lg .vs__dropdown-toggle input {\n  margin-top: 0;\n}\n.select-size-lg .vs__deselect svg {\n  vertical-align: middle !important;\n}\n[dir] .select-size-lg .vs__deselect svg {\n  transform: scale(1) !important;\n}\n[dir] .select-size-sm .vs__dropdown-toggle {\n  padding-bottom: 0;\n  padding: 1px;\n}\n[dir] .select-size-sm.vs--single .vs__dropdown-toggle {\n  padding: 2px;\n}\n.select-size-sm .vs__dropdown-toggle,\n.select-size-sm .vs__selected {\n  font-size: 0.9rem;\n}\n[dir] .select-size-sm .vs__actions {\n  padding-top: 2px;\n  padding-bottom: 2px;\n}\n.select-size-sm .vs__deselect svg {\n  vertical-align: middle !important;\n}\n[dir] .select-size-sm .vs__search {\n  margin-top: 0;\n}\n.select-size-sm.v-select .vs__selected {\n  font-size: 0.75rem;\n}\n[dir] .select-size-sm.v-select .vs__selected {\n  padding: 0 0.3rem;\n}\n[dir] .select-size-sm.v-select:not(.vs--single) .vs__selected {\n  margin: 4px 5px;\n}\n[dir] .select-size-sm.v-select.vs--single .vs__selected {\n  margin-top: 1px;\n}\n[dir] .select-size-sm.vs--single.vs--open .vs__selected {\n  margin-top: 4px;\n}\n.dark-layout .vs__dropdown-toggle {\n  color: #b4b7bd;\n}\n[dir] .dark-layout .vs__dropdown-toggle {\n  background: #283046;\n  border-color: #404656;\n}\n.dark-layout .vs__selected-options input {\n  color: #b4b7bd;\n}\n.dark-layout .vs__selected-options input::placeholder {\n  color: #676d7d;\n}\n.dark-layout .vs__actions svg {\n  fill: #404656;\n}\n[dir] .dark-layout .vs__dropdown-menu {\n  background: #283046;\n}\n.dark-layout .vs__dropdown-menu li {\n  color: #b4b7bd;\n}\n.dark-layout .v-select:not(.vs--single) .vs__selected {\n  color: #7367f0;\n}\n[dir] .dark-layout .v-select:not(.vs--single) .vs__selected {\n  background-color: rgba(115, 103, 240, 0.12);\n}\n.dark-layout .v-select.vs--single .vs__selected {\n  color: #b4b7bd !important;\n}\n.dark-layout .vs--disabled .vs__dropdown-toggle,\n.dark-layout .vs--disabled .vs__clear,\n.dark-layout .vs--disabled .vs__search,\n.dark-layout .vs--disabled .vs__selected,\n.dark-layout .vs--disabled .vs__open-indicator {\n  opacity: 0.5;\n}\n[dir] .dark-layout .vs--disabled .vs__dropdown-toggle, [dir] .dark-layout .vs--disabled .vs__clear, [dir] .dark-layout .vs--disabled .vs__search, [dir] .dark-layout .vs--disabled .vs__selected, [dir] .dark-layout .vs--disabled .vs__open-indicator {\n  background-color: #283046;\n}\n.ecommerce-application .app-ecommerce-details .product-img {\n  width: 600px;\n}\n.ecommerce-application .app-ecommerce-details .ratings-list-item svg,\n.ecommerce-application .app-ecommerce-details .ratings-list-item i {\n  font-size: 1.286rem;\n  height: 1.286rem;\n  width: 1.286rem;\n}\n.ecommerce-application .app-ecommerce-details .filled-star {\n  fill: #ff9f43;\n  stroke: #ff9f43;\n  color: #ff9f43;\n}\n.ecommerce-application .app-ecommerce-details .unfilled-star {\n  stroke: #babfc7;\n  color: #babfc7;\n}\n.ecommerce-application .app-ecommerce-details .item-price {\n  color: #7367f0;\n}\n.ecommerce-application .app-ecommerce-details .item-company {\n  display: inline-flex;\n  font-weight: 400;\n  font-size: 0.875rem;\n}\n.ecommerce-application .app-ecommerce-details .item-company .company-name {\n  font-weight: 600;\n}\n[dir=ltr] .ecommerce-application .app-ecommerce-details .item-company .company-name {\n  margin-left: 0.25rem;\n}\n[dir=rtl] .ecommerce-application .app-ecommerce-details .item-company .company-name {\n  margin-right: 0.25rem;\n}\n[dir] .ecommerce-application .app-ecommerce-details .product-features {\n  margin-top: 1.5rem;\n  margin-bottom: 1.5rem;\n}\n.ecommerce-application .app-ecommerce-details .product-features li {\n  display: flex;\n  align-items: center;\n}\n[dir] .ecommerce-application .app-ecommerce-details .product-features li {\n  margin-bottom: 1rem;\n}\n.ecommerce-application .app-ecommerce-details .product-features li svg,\n.ecommerce-application .app-ecommerce-details .product-features li i {\n  height: 1.4rem;\n  width: 1.4rem;\n  font-size: 1.4rem;\n}\n[dir=ltr] .ecommerce-application .app-ecommerce-details .product-features li svg, [dir=ltr] .ecommerce-application .app-ecommerce-details .product-features li i {\n  margin-right: 0.75rem;\n}\n[dir=rtl] .ecommerce-application .app-ecommerce-details .product-features li svg, [dir=rtl] .ecommerce-application .app-ecommerce-details .product-features li i {\n  margin-left: 0.75rem;\n}\n.ecommerce-application .app-ecommerce-details .product-features li span {\n  font-weight: 600;\n}\n[dir] .ecommerce-application .app-ecommerce-details .product-color-options {\n  margin-top: 1.5rem;\n  margin-bottom: 1.2rem;\n}\n.ecommerce-application .app-ecommerce-details .btn-wishlist .text-danger {\n  color: #ea5455;\n  fill: #ea5455;\n}\n.ecommerce-application .app-ecommerce-details .btn-share .btn-icon ~ .dropdown-menu {\n  min-width: 3rem;\n}\n[dir] .ecommerce-application .app-ecommerce-details .item-features {\n  background-color: #f8f8f8;\n  padding-top: 5.357rem;\n  padding-bottom: 5.357rem;\n}\n.ecommerce-application .app-ecommerce-details .item-features i,\n.ecommerce-application .app-ecommerce-details .item-features svg {\n  font-size: 2.5rem;\n  height: 2.5rem;\n  width: 2.5rem;\n  color: #7367f0;\n}\n[dir] .ecommerce-application .swiper-responsive-breakpoints.swiper-container .swiper-slide {\n  text-align: center;\n  background-color: #f8f8f8;\n  padding: 1.5rem 3rem;\n  border-radius: 0.428rem;\n}\n.ecommerce-application .swiper-responsive-breakpoints.swiper-container .swiper-slide .img-container {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 250px;\n}\n.ecommerce-application .swiper-button-prev,\n.ecommerce-application .swiper-button-next,\n.ecommerce-application .swiper-container-rtl .swiper-button-prev,\n.ecommerce-application .swiper-container-rtl .swiper-button-next {\n  width: 35px;\n  font-size: 2rem;\n}\n[dir] .ecommerce-application .swiper-button-prev, [dir] .ecommerce-application .swiper-button-next, [dir] .ecommerce-application .swiper-container-rtl .swiper-button-prev, [dir] .ecommerce-application .swiper-container-rtl .swiper-button-next {\n  background-image: none;\n}\n.ecommerce-application .swiper-button-prev:focus,\n.ecommerce-application .swiper-button-next:focus,\n.ecommerce-application .swiper-container-rtl .swiper-button-prev:focus,\n.ecommerce-application .swiper-container-rtl .swiper-button-next:focus {\n  outline: none;\n}\n[dir=ltr] .ecommerce-application .swiper-button-prev {\n  left: 0;\n}\n[dir=rtl] .ecommerce-application .swiper-button-prev {\n  right: 0;\n}\n.ecommerce-application .swiper-button-prev:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n[dir=ltr] .ecommerce-application .swiper-button-next {\n  right: 0;\n}\n[dir=rtl] .ecommerce-application .swiper-button-next {\n  left: 0;\n}\n.ecommerce-application .swiper-button-next:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n.ecommerce-application .swiper-container-rtl .swiper-button-prev:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-container-rtl .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n.ecommerce-application .swiper-container-rtl .swiper-button-next:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .ecommerce-application .swiper-container-rtl .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n.ecommerce-application .product-color-options .color-option {\n  position: relative;\n}\n[dir] .ecommerce-application .product-color-options .color-option {\n  border: 1px solid transparent;\n  border-radius: 50%;\n  cursor: pointer;\n  padding: 3px;\n}\n.ecommerce-application .product-color-options .color-option .filloption {\n  height: 18px;\n  width: 18px;\n}\n[dir] .ecommerce-application .product-color-options .color-option .filloption {\n  border-radius: 50%;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-primary {\n  border-color: #7367f0;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-primary .filloption {\n  box-shadow: 0 2px 4px 0 rgba(115, 103, 240, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-success {\n  border-color: #28c76f;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-success .filloption {\n  box-shadow: 0 2px 4px 0 rgba(40, 199, 111, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-danger {\n  border-color: #ea5455;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-danger .filloption {\n  box-shadow: 0 2px 4px 0 rgba(234, 84, 85, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-warning {\n  border-color: #ff9f43;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-warning .filloption {\n  box-shadow: 0 2px 4px 0 rgba(255, 159, 67, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .selected .b-info {\n  border-color: #00cfe8;\n}\n[dir] .ecommerce-application .product-color-options .selected .b-info .filloption {\n  box-shadow: 0 2px 4px 0 rgba(0, 207, 232, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-primary .filloption {\n  box-shadow: 0 2px 4px 0 rgba(115, 103, 240, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-success .filloption {\n  box-shadow: 0 2px 4px 0 rgba(40, 199, 111, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-danger .filloption {\n  box-shadow: 0 2px 4px 0 rgba(234, 84, 85, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-warning .filloption {\n  box-shadow: 0 2px 4px 0 rgba(255, 159, 67, 0.4);\n}\n[dir] .ecommerce-application .product-color-options .b-info .filloption {\n  box-shadow: 0 2px 4px 0 rgba(0, 207, 232, 0.4);\n}\n@media (max-width: 767.98px) {\n[dir] .ecommerce-application .swiper-responsive-breakpoints.swiper-container .swiper-slide {\n    padding: 1rem;\n}\n}\n@media (max-width: 767.98px) {\n.ecommerce-application .app-ecommerce-details .ratings-list-item svg,\n.ecommerce-application .app-ecommerce-details .ratings-list-item i {\n    font-size: 1rem;\n    height: 1rem;\n    width: 1rem;\n}\n}\n[dir] .swal2-container .swal2-popup {\n  border-radius: 0.428rem;\n  padding: 2rem;\n}\n.swal2-container .swal2-popup .swal2-close:focus {\n  outline: none;\n}\n[dir] .swal2-container .swal2-popup .swal2-close:focus {\n  box-shadow: none;\n}\n.swal2-container .swal2-popup .swal2-content {\n  color: #6e6b7b;\n}\n.swal2-container .swal2-popup .swal2-title {\n  font-size: 1.5rem;\n  font-weight: inherit;\n  color: #5e5873;\n}\n[dir] .swal2-container .swal2-popup button.swal2-confirm:focus {\n  box-shadow: none;\n}\n.swal2-container .swal2-popup input.swal2-input {\n  height: 2.714rem;\n  font-size: 1rem;\n  color: #6e6b7b;\n  line-height: 1.45;\n}\n[dir] .swal2-container .swal2-popup input.swal2-input {\n  padding: 0.438rem 1rem;\n  border-color: #d8d6de;\n  border-radius: 0.357rem;\n}\n[dir] .swal2-container .swal2-popup input.swal2-input:focus {\n  border-color: #7367f0 !important;\n  box-shadow: 0 3px 10px 0 rgba(34, 41, 47, 0.1);\n}\n[dir] .swal2-container .swal2-popup .swal2-progress-steps .swal2-progress-step {\n  background-color: #7367f0;\n}\n[dir] .swal2-container .swal2-popup .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step ~ .swal2-progress-step-line, [dir] .swal2-container .swal2-popup .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step ~ .swal2-progress-step {\n  background-color: #b3adf7;\n}\n[dir] .swal2-container .swal2-popup .swal2-progress-steps .swal2-progress-step-line {\n  background-color: #7367f0;\n}\n.swal2-container .swal2-popup pre {\n  min-height: 1.35rem;\n}\n[dir] .swal2-container .swal2-popup pre {\n  margin-top: 0.5rem;\n}\n.swal2-container .swal2-popup .swal2-footer {\n  color: #6e6b7b;\n}\n[dir] .swal2-container .swal2-popup .swal2-footer {\n  border-color: #d8d6de;\n}\n[dir] .dark-layout .swal2-container .swal2-modal {\n  background-color: #283046;\n}\n.dark-layout .swal2-container .swal2-modal .swal2-header .swal2-title {\n  color: #d0d2d6;\n}\n.dark-layout .swal2-container .swal2-modal .swal2-header .swal2-icon-text {\n  color: inherit;\n}\n[dir] .dark-layout .swal2-container .swal2-modal .swal2-header .swal2-success-circular-line-left, [dir] .dark-layout .swal2-container .swal2-modal .swal2-header .swal2-success-circular-line-right, [dir] .dark-layout .swal2-container .swal2-modal .swal2-header .swal2-success-fix, [dir] .dark-layout .swal2-container .swal2-modal .swal2-header .swal2-animate-success-icon {\n  background-color: #283046 !important;\n}\n.dark-layout .swal2-container .swal2-modal input.swal2-input {\n  color: #b4b7bd;\n}\n[dir] .dark-layout .swal2-container .swal2-modal input.swal2-input {\n  border-color: #3b4253;\n}\n.dark-layout .swal2-container .swal2-modal .swal2-content {\n  color: #b4b7bd;\n}\n.dark-layout .swal2-container .swal2-modal pre,\n.dark-layout .swal2-container .swal2-modal code {\n  color: #b4b7bd;\n}\n[dir] .dark-layout .swal2-container .swal2-modal .swal2-input {\n  background-color: #283046;\n}\n.dark-layout .swal2-container .swal2-modal .swal2-footer {\n  color: #b4b7bd;\n}\n[dir] .dark-layout .swal2-container .swal2-modal .swal2-footer {\n  border-color: #3b4253;\n}\nhtml[dir=rtl] .swal2-rtl .swal2-close {\n  left: 0;\n  right: auto;\n}\n.product-image-container {\n  width: 60px;\n  height: 60px;\n  overflow: hidden;\n}\n[dir] .product-image-container {\n  border-radius: 4px;\n}\n[dir=ltr] .product-image-container {\n  margin-right: 10px;\n}\n[dir=rtl] .product-image-container {\n  margin-left: 10px;\n}\n.product-image-container img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.product-details {\n  flex-grow: 1;\n  /* Agrega un margen a la izquierda */\n}\n[dir=ltr] .product-details {\n  margin-left: 10px;\n}\n[dir=rtl] .product-details {\n  margin-right: 10px;\n}\n\n/* Estilos para dispositivos móviles */\n@media screen and (max-width: 767px) {\n.form-textarea {\n    font-size: 16px;\n    /* Tamaño de letra para dispositivos móviles */\n}\n}\n/* Estilos para dispositivos no móviles */\n@media screen and (min-width: 768px) {\n.form-textarea {\n    font-size: 15px;\n    /* Tamaño de letra para dispositivos no móviles */\n}\n}\n.form-textarea {\n  text-transform: uppercase;\n}\n.montos {\n  font-size: 24px;\n  /* Ajusta el tamaño de fuente según tus preferencias */\n  font-weight: bold;\n  /* Hace que el texto sea negrita */\n  color: #007bff;\n  /* Cambia el color del texto, si lo deseas */\n  /* Agrega otros estilos según tus preferencias */\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaVenta.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./frm_Venta.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "toastification" }, [
    _c(
      "div",
      { staticClass: "d-flex align-items-start" },
      [
        _c(
          "b-avatar",
          {
            staticClass: "mr-75 flex-shrink-0",
            attrs: { variant: _vm.variant, size: "1.8rem" },
          },
          [_c("feather-icon", { attrs: { icon: _vm.icon, size: "15" } })],
          1
        ),
        _vm._v(" "),
        _c("div", { staticClass: "d-flex flex-grow-1" }, [
          _c("div", [
            _vm.title
              ? _c("h5", {
                  staticClass: "mb-0 font-weight-bolder toastification-title",
                  class: "text-" + _vm.variant,
                  domProps: { textContent: _vm._s(_vm.title) },
                })
              : _vm._e(),
            _vm._v(" "),
            _vm.text
              ? _c("small", {
                  staticClass: "d-inline-block text-body",
                  domProps: { textContent: _vm._s(_vm.text) },
                })
              : _vm._e(),
          ]),
          _vm._v(" "),
          _c(
            "span",
            {
              staticClass: "cursor-pointer toastification-close-icon ml-auto ",
              on: {
                click: function ($event) {
                  return _vm.$emit("close-toast")
                },
              },
            },
            [
              !_vm.hideClose
                ? _c("feather-icon", {
                    staticClass: "text-body",
                    attrs: { icon: "XIcon" },
                  })
                : _vm._e(),
            ],
            1
          ),
        ]),
      ],
      1
    ),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=template&id=ae6d31d6&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=template&id=ae6d31d6& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "section",
    [
      _c(
        "div",
        [
          _c(
            "b-modal",
            {
              ref: "frm-ventas",
              attrs: {
                id: "frm-ventas",
                "ok-title": "Cerrar",
                "ok-variant": "danger",
                "ok-only": "",
                size: "xl",
                centered: "",
                title: "Registro de Venta",
                "no-close-on-backdrop": "",
              },
              on: { ok: _vm.obtenerVentasRealizadas },
            },
            [_c("Frm_Venta")],
            1
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              ref: "frm-nota",
              attrs: {
                id: "frm-nota",
                "ok-title": "Cerrar",
                "ok-variant": "danger",
                "ok-only": "",
                size: "xl",
                centered: "",
                title: "Registro de Venta",
                "no-close-on-backdrop": "",
              },
              on: { ok: _vm.obtenerVentasRealizadas },
            },
            [_c("div", [_c("frm-nota-venta")], 1)]
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-row",
        [
          _c(
            "b-col",
            { attrs: { md: "9" } },
            [
              _c(
                "b-overlay",
                {
                  attrs: {
                    id: "overlay-background",
                    variant: _vm.variant,
                    opacity: _vm.opacity,
                    blur: _vm.blur,
                  },
                },
                [
                  _c(
                    "b-card",
                    { attrs: { "border-variant": "info" } },
                    [
                      _c(
                        "b-card-title",
                        { staticStyle: { "text-align": "center" } },
                        [_vm._v("Listado de Ventas")]
                      ),
                      _vm._v(" "),
                      _c(
                        "b-card-body",
                        [
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c(
                                    "b-button-toolbar",
                                    [
                                      _c(
                                        "b-button-group",
                                        { staticClass: "mr-2 mb-1" },
                                        [
                                          _c(
                                            "b-button",
                                            {
                                              directives: [
                                                {
                                                  name: "ripple",
                                                  rawName: "v-ripple.400",
                                                  value:
                                                    "rgba(113, 102, 240, 0.15)",
                                                  expression:
                                                    "'rgba(113, 102, 240, 0.15)'",
                                                  modifiers: { 400: true },
                                                },
                                              ],
                                              attrs: {
                                                variant: "flat-success",
                                                href: "https://pweb.impuestos.gob.bo/Autenticacion/index.xhtml",
                                                target: "_blank",
                                              },
                                            },
                                            [
                                              _c("feather-icon", {
                                                attrs: { icon: "GlobeIcon" },
                                              }),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                { staticClass: "align-middle" },
                                                [_vm._v("Facturación")]
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                {
                                  staticClass: "mb-1",
                                  attrs: { sm: "4", md: "5", xl: "6", lg: "6" },
                                },
                                [
                                  _c(
                                    "b-button",
                                    {
                                      directives: [
                                        {
                                          name: "ripple",
                                          rawName: "v-ripple.400",
                                          value: "rgba(113, 102, 240, 0.15)",
                                          expression:
                                            "'rgba(113, 102, 240, 0.15)'",
                                          modifiers: { 400: true },
                                        },
                                        {
                                          name: "b-modal",
                                          rawName: "v-b-modal.frm-ventas",
                                          modifiers: { "frm-ventas": true },
                                        },
                                      ],
                                      class: {
                                        "d-none": _vm.$store.state.app.isCrea,
                                      },
                                      attrs: { variant: "success" },
                                      on: {
                                        click: function ($event) {
                                          return _vm.clickAccion("", "guardar")
                                        },
                                      },
                                    },
                                    [
                                      _vm._v(
                                        "\n                                    Nuevo Registro\n                                "
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "b-button",
                                    {
                                      directives: [
                                        {
                                          name: "ripple",
                                          rawName: "v-ripple.400",
                                          value: "rgba(255, 255, 255, 0.15)",
                                          expression:
                                            "'rgba(255, 255, 255, 0.15)'",
                                          modifiers: { 400: true },
                                        },
                                      ],
                                      class: _vm.$store.state.app.classButton,
                                      attrs: {
                                        variant: _vm.$store.state.app.variant,
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.CierreCaja()
                                        },
                                      },
                                    },
                                    [
                                      _c("feather-icon", {
                                        staticClass: "mr-50",
                                        attrs: {
                                          icon: _vm.$store.state.app.botonIcono,
                                        },
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "span",
                                        { staticClass: "align-middle" },
                                        [_vm._v("Cerrar Caja ")]
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "b-col",
                                {
                                  attrs: { sm: "8", md: "7", xl: "6", lg: "6" },
                                },
                                [
                                  _c(
                                    "b-form-group",
                                    { attrs: { "label-for": "filter-input" } },
                                    [
                                      _c(
                                        "b-input-group",
                                        [
                                          _c("b-form-input", {
                                            attrs: {
                                              id: "filter-input",
                                              debounce: "200",
                                              type: "search",
                                              placeholder:
                                                "Esccribe Para Buscar",
                                            },
                                            model: {
                                              value: _vm.filter,
                                              callback: function ($$v) {
                                                _vm.filter = $$v
                                              },
                                              expression: "filter",
                                            },
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "b-input-group-append",
                                            [
                                              _c(
                                                "b-button",
                                                {
                                                  attrs: {
                                                    disabled: !_vm.filter,
                                                    variant: "danger",
                                                  },
                                                  on: {
                                                    click: function ($event) {
                                                      _vm.filter = ""
                                                    },
                                                  },
                                                },
                                                [_vm._v("Limpiar")]
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c("b-table", {
                                    attrs: {
                                      id: "tabla-lista-ventas",
                                      items: _vm.items,
                                      fields: _vm.fields,
                                      filter: _vm.filter,
                                      hover: "",
                                      responsive: "sm",
                                      busy: _vm.isBusy,
                                      outlined: "",
                                      "sticky-header": _vm.stickyHeader,
                                    },
                                    on: { filtered: _vm.onFiltered },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "cell(artCantidad)",
                                        fn: function (data) {
                                          return [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "d-flex align-items-center",
                                              },
                                              [
                                                _c("b-form-input", {
                                                  staticClass: "small-input",
                                                  attrs: {
                                                    id: "txtCantidad",
                                                    placeholder: "Cantidad",
                                                    state:
                                                      data.item.artCantidad > 0
                                                        ? true
                                                        : false,
                                                    type: "number",
                                                    min: 1,
                                                  },
                                                  model: {
                                                    value:
                                                      data.item.artCantidad,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        data.item,
                                                        "artCantidad",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "data.item.artCantidad",
                                                  },
                                                }),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                      {
                                        key: "cell(Acción)",
                                        fn: function (row) {
                                          return [
                                            _c(
                                              "b-row",
                                              [
                                                _c(
                                                  "b-col",
                                                  [
                                                    _c(
                                                      "b-button",
                                                      {
                                                        directives: [
                                                          {
                                                            name: "ripple",
                                                            rawName:
                                                              "v-ripple.400",
                                                            value:
                                                              "rgba(255, 255, 255, 0.15)",
                                                            expression:
                                                              "'rgba(255, 255, 255, 0.15)'",
                                                            modifiers: {
                                                              400: true,
                                                            },
                                                          },
                                                          {
                                                            name: "b-tooltip",
                                                            rawName:
                                                              "v-b-tooltip.hover.v-dark",
                                                            modifiers: {
                                                              hover: true,
                                                              "v-dark": true,
                                                            },
                                                          },
                                                        ],
                                                        staticClass: "btn-icon",
                                                        class: {
                                                          "d-none":
                                                            _vm.$store.state.app
                                                              .isEdita,
                                                        },
                                                        attrs: {
                                                          variant:
                                                            "flat-warning",
                                                          title:
                                                            "Seguir Editando",
                                                        },
                                                        on: {
                                                          click: function (
                                                            $event
                                                          ) {
                                                            _vm.clickAccion(
                                                              row.item,
                                                              "editar"
                                                            )
                                                          },
                                                        },
                                                      },
                                                      [
                                                        _c("feather-icon", {
                                                          attrs: {
                                                            icon: "EditIcon",
                                                          },
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                  ],
                                                  1
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "b-col",
                                                  [
                                                    _c(
                                                      "b-button",
                                                      {
                                                        directives: [
                                                          {
                                                            name: "ripple",
                                                            rawName:
                                                              "v-ripple.400",
                                                            value:
                                                              "rgba(255, 255, 255, 0.15)",
                                                            expression:
                                                              "'rgba(255, 255, 255, 0.15)'",
                                                            modifiers: {
                                                              400: true,
                                                            },
                                                          },
                                                          {
                                                            name: "b-tooltip",
                                                            rawName:
                                                              "v-b-tooltip.hover.v-dark",
                                                            modifiers: {
                                                              hover: true,
                                                              "v-dark": true,
                                                            },
                                                          },
                                                        ],
                                                        staticClass: "btn-icon",
                                                        class: {
                                                          "d-none":
                                                            _vm.$store.state.app
                                                              .isVer,
                                                        },
                                                        attrs: {
                                                          variant:
                                                            "flat-success",
                                                          title: "Ver Detalle",
                                                        },
                                                        on: {
                                                          click: function (
                                                            $event
                                                          ) {
                                                            _vm.clickAccion(
                                                              row.item,
                                                              "ver"
                                                            )
                                                          },
                                                        },
                                                      },
                                                      [
                                                        _c("feather-icon", {
                                                          attrs: {
                                                            icon: "EyeIcon",
                                                          },
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                  ],
                                                  1
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "b-col",
                                                  [
                                                    _c(
                                                      "b-button",
                                                      {
                                                        directives: [
                                                          {
                                                            name: "ripple",
                                                            rawName:
                                                              "v-ripple.400",
                                                            value:
                                                              "rgba(255, 255, 255, 0.15)",
                                                            expression:
                                                              "'rgba(255, 255, 255, 0.15)'",
                                                            modifiers: {
                                                              400: true,
                                                            },
                                                          },
                                                        ],
                                                        staticClass:
                                                          "btn-icon rounded-circle",
                                                        class: {
                                                          "d-none":
                                                            _vm.$store.state.app
                                                              .isElimina,
                                                        },
                                                        attrs: {
                                                          variant:
                                                            "flat-danger",
                                                        },
                                                        on: {
                                                          click: function (
                                                            $event
                                                          ) {
                                                            _vm.clickAccion(
                                                              row.item,
                                                              "eliminar"
                                                            )
                                                          },
                                                        },
                                                      },
                                                      [
                                                        _c("feather-icon", {
                                                          attrs: {
                                                            icon: "TrashIcon",
                                                          },
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                  ],
                                                  1
                                                ),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                      {
                                        key: "table-busy",
                                        fn: function () {
                                          return [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "text-center text-danger my-2",
                                              },
                                              [
                                                _c("b-spinner", {
                                                  staticClass: "align-middle",
                                                }),
                                                _vm._v(" "),
                                                _c("strong", [
                                                  _vm._v("Cargando..."),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                        proxy: true,
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { md: "3" } },
            [
              _c(
                "b-card",
                { attrs: { "border-variant": "info" } },
                [
                  _c("b-card-body", [
                    _vm._v(
                      "\n                    Ventas Contado :" +
                        _vm._s(_vm.totalVentaSum) +
                        "\n                "
                    ),
                  ]),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=template&id=a49a20e4&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=template&id=a49a20e4& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("button", { on: { click: _vm.generatePDF } }, [_vm._v("Generar PDF")]),
    _vm._v(" "),
    _c("div", { attrs: { id: "contenido-pdf" } }, [
      _c("h1", [_vm._v("Nota de Venta")]),
      _vm._v(" "),
      _c("p", [
        _c("strong", [_vm._v("Cliente:")]),
        _vm._v(
          " Cliente de ejemplo " + _vm._s(_vm.$store.state.app.NombreEmpresa)
        ),
      ]),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=template&id=2db62a52&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=template&id=2db62a52& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "section",
    [
      _c(
        "b-row",
        [
          _c(
            "b-col",
            { attrs: { sm: "12", md: "3", xl: "3" } },
            [
              _c(
                "b-row",
                [
                  _c(
                    "b-col",
                    [
                      _c(
                        "b-card",
                        { attrs: { "border-variant": "info" } },
                        [
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                { attrs: { sm: "12", md: "12", xl: "12" } },
                                [
                                  _c(
                                    "b-form-group",
                                    [
                                      _c(
                                        "label",
                                        { attrs: { for: "tipoPago" } },
                                        [_vm._v("Cliente")]
                                      ),
                                      _vm._v(" "),
                                      _c("v-select", {
                                        staticClass: "select-size-lg",
                                        attrs: {
                                          options: _vm.gntCliente,
                                          label: "title",
                                          placeholder: "Seleccionar Cliente",
                                          "max-options": 3,
                                        },
                                        model: {
                                          value: _vm.selectedCliente,
                                          callback: function ($$v) {
                                            _vm.selectedCliente = $$v
                                          },
                                          expression: "selectedCliente",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                { attrs: { sm: "12", md: "12", xl: "12" } },
                                [
                                  _c(
                                    "b-form-group",
                                    [
                                      _c(
                                        "label",
                                        { attrs: { for: "tipoPago" } },
                                        [_vm._v("Tipo Venta")]
                                      ),
                                      _vm._v(" "),
                                      _c("v-select", {
                                        staticClass: "select-size-lg",
                                        attrs: {
                                          options: _vm.tipoVenta,
                                          label: "title",
                                          placeholder: "Seleccionar",
                                          "max-options": 3,
                                        },
                                        model: {
                                          value: _vm.selectedTipoVenta,
                                          callback: function ($$v) {
                                            _vm.selectedTipoVenta = $$v
                                          },
                                          expression: "selectedTipoVenta",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                { attrs: { sm: "12", md: "12", xl: "12" } },
                                [
                                  _c(
                                    "b-form-group",
                                    [
                                      _c(
                                        "label",
                                        { attrs: { for: "tipoPago" } },
                                        [_vm._v("Forma de Pago")]
                                      ),
                                      _vm._v(" "),
                                      _c("v-select", {
                                        staticClass: "select-size-lg",
                                        attrs: {
                                          options: _vm.tiposPago,
                                          label: "title",
                                          placeholder: "Seleccionar",
                                          "max-options": 3,
                                        },
                                        model: {
                                          value: _vm.SelectedtipoPago,
                                          callback: function ($$v) {
                                            _vm.SelectedtipoPago = $$v
                                          },
                                          expression: "SelectedtipoPago",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c(
                                    "b-form-group",
                                    [
                                      _c("label", [_vm._v("Total a Pagar")]),
                                      _vm._v(" "),
                                      _c("b-form-input", {
                                        staticClass: "montos",
                                        attrs: { disabled: "" },
                                        model: {
                                          value: _vm.totalPagarCalculado,
                                          callback: function ($$v) {
                                            _vm.totalPagarCalculado = $$v
                                          },
                                          expression: "totalPagarCalculado",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c(
                                    "b-form-group",
                                    [
                                      _c(
                                        "label",
                                        { attrs: { for: "montoRecibido" } },
                                        [_vm._v("Monto Recibido")]
                                      ),
                                      _vm._v(" "),
                                      _c("b-form-input", {
                                        staticClass: "montos",
                                        attrs: { id: "montoRecibido" },
                                        model: {
                                          value: _vm.montoRecibido,
                                          callback: function ($$v) {
                                            _vm.montoRecibido = $$v
                                          },
                                          expression: "montoRecibido",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "b-col",
                                [
                                  _c(
                                    "b-form-group",
                                    [
                                      _c("label", [_vm._v("Cambio")]),
                                      _vm._v(" "),
                                      _c("b-form-input", {
                                        staticClass: "montos",
                                        attrs: { disabled: "" },
                                        model: {
                                          value: _vm.cambio,
                                          callback: function ($$v) {
                                            _vm.cambio = $$v
                                          },
                                          expression: "cambio",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { staticClass: "mb-1", attrs: { sm: "12", md: "9", xl: "9" } },
            [
              _c(
                "b-row",
                [
                  _c(
                    "b-col",
                    [
                      _c(
                        "b-card",
                        { attrs: { "border-variant": "info" } },
                        [
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c(
                                    "b-form-group",
                                    [
                                      _c(
                                        "label",
                                        { staticClass: "d-inline d-lg-flex" },
                                        [_vm._v("Buscar Producto")]
                                      ),
                                      _vm._v(" "),
                                      _c("v-select", {
                                        ref: "selectedProductos",
                                        staticClass: "select-size-lg",
                                        attrs: {
                                          options: _vm.booksProductos,
                                          label: "title",
                                          placeholder: "Seleccionar",
                                          "max-options": 3,
                                        },
                                        on: {
                                          input: function ($event) {
                                            return _vm.cargarProducto()
                                          },
                                        },
                                        scopedSlots: _vm._u([
                                          {
                                            key: "option",
                                            fn: function (ref) {
                                              var title = ref.title
                                              var icon = ref.icon
                                              var precioV = ref.precioV
                                              var cantidad = ref.cantidad
                                              return [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "d-flex align-items-center",
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "product-image-container",
                                                      },
                                                      [
                                                        icon
                                                          ? _c("img", {
                                                              attrs: {
                                                                src:
                                                                  "data:image/jpeg;base64," +
                                                                  icon,
                                                                alt: "Sin Foto",
                                                              },
                                                            })
                                                          : _vm._e(),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "product-details",
                                                      },
                                                      [
                                                        _c("strong", [
                                                          _vm._v(_vm._s(title)),
                                                        ]),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "text-secondary ",
                                                          },
                                                          [
                                                            _vm._v(
                                                              "Precio: " +
                                                                _vm._s(precioV)
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "text-secondary ",
                                                          },
                                                          [
                                                            _vm._v(
                                                              "Stock: " +
                                                                _vm._s(cantidad)
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            },
                                          },
                                        ]),
                                        model: {
                                          value: _vm.selectedProductos,
                                          callback: function ($$v) {
                                            _vm.selectedProductos = $$v
                                          },
                                          expression: "selectedProductos",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-row",
                            [
                              _c(
                                "b-col",
                                [
                                  _c("b-table", {
                                    attrs: {
                                      id: "tabla-lista-retrasos",
                                      items: _vm.itemsAgregado,
                                      fields: _vm.fieldsAgregado,
                                      filter: _vm.filter,
                                      hover: "",
                                      busy: _vm.isBusy,
                                      bordered: true,
                                      fixed: true,
                                      "sticky-header": _vm.stickyHeader,
                                      "head-variant": _vm.headVariant,
                                    },
                                    on: { filtered: _vm.onFiltered },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "cell(cantidad)",
                                        fn: function (row) {
                                          return [
                                            _c("b-form-input", {
                                              directives: [
                                                {
                                                  name: "b-tooltip",
                                                  rawName:
                                                    "v-b-tooltip.hover.top.right",
                                                  value:
                                                    row.value > 0
                                                      ? ""
                                                      : "Cantidad debe ser mayor que cero",
                                                  expression:
                                                    "row.value > 0 ? '' : 'Cantidad debe ser mayor que cero'",
                                                  modifiers: {
                                                    hover: true,
                                                    top: true,
                                                    right: true,
                                                  },
                                                },
                                              ],
                                              ref: "cantidadInput",
                                              staticClass:
                                                "v-b-tooltip-dark text-center",
                                              attrs: {
                                                type: "number",
                                                min: "1",
                                                state:
                                                  row.value > 0 ? true : false,
                                                show: row.value === 0,
                                                trigger: "hover focus",
                                              },
                                              on: {
                                                input: function ($event) {
                                                  return _vm.actualizarCantidad(
                                                    row.item,
                                                    row.value
                                                  )
                                                },
                                              },
                                              model: {
                                                value: row.value,
                                                callback: function ($$v) {
                                                  _vm.$set(row, "value", $$v)
                                                },
                                                expression: "row.value",
                                              },
                                            }),
                                          ]
                                        },
                                      },
                                      {
                                        key: "cell(descuento)",
                                        fn: function (row) {
                                          return [
                                            _c("b-form-input", {
                                              directives: [
                                                {
                                                  name: "b-tooltip",
                                                  rawName:
                                                    "v-b-tooltip.hover.top.right",
                                                  value:
                                                    row.value > row.item.precioV
                                                      ? "Descuento No Valido"
                                                      : "Cantidad debe ser mayor que cero",
                                                  expression:
                                                    "row.value > row.item.precioV ? 'Descuento No Valido' : 'Cantidad debe ser mayor que cero'",
                                                  modifiers: {
                                                    hover: true,
                                                    top: true,
                                                    right: true,
                                                  },
                                                },
                                              ],
                                              ref: "descuentoInput",
                                              staticClass:
                                                "v-b-tooltip-dark text-center",
                                              attrs: {
                                                type: "number",
                                                min: "1",
                                                state:
                                                  row.value > 0 ? true : false,
                                                show: row.value === 0,
                                                trigger: "hover focus",
                                              },
                                              on: {
                                                input: function ($event) {
                                                  return _vm.precioDescuento(
                                                    row.item,
                                                    row.value
                                                  )
                                                },
                                              },
                                              model: {
                                                value: row.value,
                                                callback: function ($$v) {
                                                  _vm.$set(row, "value", $$v)
                                                },
                                                expression: "row.value",
                                              },
                                            }),
                                          ]
                                        },
                                      },
                                      {
                                        key: "cell(subtotal)",
                                        fn: function (row) {
                                          return [
                                            _vm._v(
                                              "\n                                        " +
                                                _vm._s(
                                                  row.item.descuento > 0
                                                    ? row.item.descuento *
                                                        row.item.cantidad
                                                    : row.item.precioV *
                                                        row.item.cantidad
                                                ) +
                                                "\n                                    "
                                            ),
                                          ]
                                        },
                                      },
                                      {
                                        key: "cell(Acción)",
                                        fn: function (row) {
                                          return [
                                            _c(
                                              "b-button",
                                              {
                                                directives: [
                                                  {
                                                    name: "ripple",
                                                    rawName: "v-ripple.400",
                                                    value:
                                                      "rgba(255, 255, 255, 0.15)",
                                                    expression:
                                                      "'rgba(255, 255, 255, 0.15)'",
                                                    modifiers: { 400: true },
                                                  },
                                                ],
                                                staticClass:
                                                  "btn-icon rounded-circle",
                                                class: {
                                                  "d-none":
                                                    _vm.$store.state.app
                                                      .isElimina,
                                                },
                                                attrs: {
                                                  variant: "flat-danger",
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    _vm.clickAccion(
                                                      row.item,
                                                      row.index,
                                                      "eliminar"
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c("feather-icon", {
                                                  attrs: { icon: "TrashIcon" },
                                                }),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                      {
                                        key: "table-busy",
                                        fn: function () {
                                          return [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "text-center text-danger my-2",
                                              },
                                              [
                                                _c("b-spinner", {
                                                  staticClass: "align-middle",
                                                }),
                                                _vm._v(" "),
                                                _c("strong", [
                                                  _vm._v("Cargando..."),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                        proxy: true,
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-row",
                [
                  _c(
                    "b-col",
                    [
                      _c(
                        "b-button",
                        {
                          directives: [
                            {
                              name: "ripple",
                              rawName: "v-ripple.400",
                              value: "rgba(255, 255, 255, 0.15)",
                              expression: "'rgba(255, 255, 255, 0.15)'",
                              modifiers: { 400: true },
                            },
                          ],
                          class: _vm.$store.state.app.classButton,
                          attrs: { variant: _vm.$store.state.app.variant },
                          on: {
                            click: function ($event) {
                              return _vm.validaOperacion(
                                _vm.$store.state.app.TipoAccion
                              )
                            },
                          },
                        },
                        [
                          _c("feather-icon", {
                            staticClass: "mr-50",
                            attrs: { icon: _vm.$store.state.app.botonIcono },
                          }),
                          _vm._v(" "),
                          _c("span", { staticClass: "align-middle" }, [
                            _vm._v(
                              _vm._s(_vm.$store.state.app.botonTexto) + " "
                            ),
                          ]),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("button", { on: { click: _vm.generatePDF } }, [
                    _vm._v("Generar PDF"),
                  ]),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/@core/components/toastification/ToastificationContent.vue":
/*!************************************************************************************!*\
  !*** ./resources/js/src/@core/components/toastification/ToastificationContent.vue ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToastificationContent_vue_vue_type_template_id_7834b2fa_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true& */ "./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true&");
/* harmony import */ var _ToastificationContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToastificationContent.vue?vue&type=script&lang=js& */ "./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _ToastificationContent_vue_vue_type_style_index_0_id_7834b2fa_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true& */ "./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ToastificationContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ToastificationContent_vue_vue_type_template_id_7834b2fa_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ToastificationContent_vue_vue_type_template_id_7834b2fa_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7834b2fa",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/@core/components/toastification/ToastificationContent.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ToastificationContent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true&":
/*!**********************************************************************************************************************************************!*\
  !*** ./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true& ***!
  \**********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_style_index_0_id_7834b2fa_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=style&index=0&id=7834b2fa&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_style_index_0_id_7834b2fa_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_style_index_0_id_7834b2fa_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_style_index_0_id_7834b2fa_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_style_index_0_id_7834b2fa_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true&":
/*!*******************************************************************************************************************************!*\
  !*** ./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true& ***!
  \*******************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_template_id_7834b2fa_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/@core/components/toastification/ToastificationContent.vue?vue&type=template&id=7834b2fa&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_template_id_7834b2fa_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ToastificationContent_vue_vue_type_template_id_7834b2fa_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ListaVenta_vue_vue_type_template_id_ae6d31d6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ListaVenta.vue?vue&type=template&id=ae6d31d6& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=template&id=ae6d31d6&");
/* harmony import */ var _ListaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ListaVenta.vue?vue&type=script&lang=js& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _ListaVenta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ListaVenta.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ListaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ListaVenta_vue_vue_type_template_id_ae6d31d6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ListaVenta_vue_vue_type_template_id_ae6d31d6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaVenta.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaVenta.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=template&id=ae6d31d6&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=template&id=ae6d31d6& ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_template_id_ae6d31d6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaVenta.vue?vue&type=template&id=ae6d31d6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/ListaVenta.vue?vue&type=template&id=ae6d31d6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_template_id_ae6d31d6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaVenta_vue_vue_type_template_id_ae6d31d6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _frmNotaVenta_vue_vue_type_template_id_a49a20e4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./frmNotaVenta.vue?vue&type=template&id=a49a20e4& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=template&id=a49a20e4&");
/* harmony import */ var _frmNotaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./frmNotaVenta.vue?vue&type=script&lang=js& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _frmNotaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _frmNotaVenta_vue_vue_type_template_id_a49a20e4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _frmNotaVenta_vue_vue_type_template_id_a49a20e4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frmNotaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./frmNotaVenta.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frmNotaVenta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=template&id=a49a20e4&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=template&id=a49a20e4& ***!
  \************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_frmNotaVenta_vue_vue_type_template_id_a49a20e4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./frmNotaVenta.vue?vue&type=template&id=a49a20e4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/Reportes/frmNotaVenta.vue?vue&type=template&id=a49a20e4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_frmNotaVenta_vue_vue_type_template_id_a49a20e4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_frmNotaVenta_vue_vue_type_template_id_a49a20e4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _frm_Venta_vue_vue_type_template_id_2db62a52___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./frm_Venta.vue?vue&type=template&id=2db62a52& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=template&id=2db62a52&");
/* harmony import */ var _frm_Venta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./frm_Venta.vue?vue&type=script&lang=js& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _frm_Venta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./frm_Venta.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _frm_Venta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _frm_Venta_vue_vue_type_template_id_2db62a52___WEBPACK_IMPORTED_MODULE_0__["render"],
  _frm_Venta_vue_vue_type_template_id_2db62a52___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./frm_Venta.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./frm_Venta.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=template&id=2db62a52&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=template&id=2db62a52& ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_template_id_2db62a52___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./frm_Venta.vue?vue&type=template&id=2db62a52& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/FormularioRegistros/abm-Ventas/frm_Venta.vue?vue&type=template&id=2db62a52&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_template_id_2db62a52___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_frm_Venta_vue_vue_type_template_id_2db62a52___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);