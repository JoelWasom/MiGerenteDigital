<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class rem_vs_pre_usd extends Model
{
    use HasFactory;
}
